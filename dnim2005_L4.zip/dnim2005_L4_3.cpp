// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Azonosito: dnim2005
//
// Lab4 3. feladat
//
// TSP
// Adott egy iranyitott graf. Hatarozzuk meg a benne talalhato legrovidebb Hamilton-kort.

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

#define MAX 9999999

using namespace std;

string inout = "lab4_3_5.";

void Beolvas(int**& graf, int& n, int& m);

void Init_Memo(int** memo, int n, int** graf);

int Bellman_Held_Karp(int** graf, int u, int S, int** memo, int n);

void Kiir(int min);

int main()
{
	int** graf = new int*[1];
	int n, m;

	Beolvas(graf, n, m);

	int** memo = new int* [n];					//lefoglaljuk a helyet a memo tombnek
	for (int i = 0; i < n; ++i)
	{
		memo[i] = new int[pow(2, n)];
	}

	Init_Memo(memo, n, graf);

	int min = Bellman_Held_Karp(graf, 0, ((1 << n) - 1), memo, n);

	Kiir(min);

	for (int i = n - 1; i >= 0; --i)
	{
		delete[] graf[i];
		delete[] memo[i];
	}

	delete[] memo;
	delete[]graf;

	return 0;
}

void Beolvas(int**& graf, int& n, int& m)		//beolvassuk a grafot szovegallomanybol
{
	ifstream in(inout + "in");

	in >> n >> m;

	graf = new int* [n] {0};
	for (int i = 0; i < n; ++i)
		graf[i] = new int[n] {0};

	int u, v, g;

	for (int i = 0; i < m; ++i)
	{
		in >> u >> v >> g;
		u--;	v--;

		graf[u][v] = g;
	}

	in.close();
}

void Init_Memo(int** memo, int n, int** graf)			//inicializaljuk a memo ketdimenzios tomobt
{
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < pow(2, n); ++j)
			memo[i][j] = -1;
	}
	memo[0][1] = 0;				//minden az 1-es (itt 0-as az indexeles miatt) kivetelevel -1 lesz

	for (int i = 0; i < n; ++i)
	{
		if (graf[0][i] != 0)
		{
			memo[0][(1 << i)] = graf[0][i];
		}
	}
}

int Bellman_Held_Karp(int** graf, int u, int S, int** memo, int n)		//fuggveny amely kiszamolja egy graf minimalis Hamilton-koret
{
	int& ref = memo[u][S];

	if (ref != -1)		//ha mar ki van szamolva a memo[u][S] akkor azt teritjuk vissza
	{
		return ref;
	}
	else
	{
		int min;
		if (S != 0)			//kulonben nezzuk, hogy az utvonalban meg vannak-e csucsok
		{
			min = MAX;
			for (int i = 0; i < n; ++i)		//vesszuk az i-bol kimeno szomszedokat u-nak
			{
				if ((i != u) && (graf[i][u] != 0) && (S & (1 << i)))		//ha szomszedosak, kulonboznek es az i resze az utvonalnak
				{
					int s = S ^ (1 << i);		//akkor kivesszuk az utvonalbol i-t

					memo[u][S] = Bellman_Held_Karp(graf, i, s, memo, n) + graf[i][u];		//memo[u][S] pedig megkapja az s utvonalbol a minimalis utat + az i es u kozti tavolsagot

					if (memo[u][S] < min)		//kozben nezzuk, hogy talaltunk-e kisebb erteket az elozoknel
					{
						min = memo[u][S];
					}
				}
			}
		}
		else
		{
			min = 0;	//ha az utvonal ures akkor a min = 0 lesz
		}

		return ref = min;		//visszateritjuk a ref-et aminek az erteke min lesz
	}
}

void Kiir(int min)		//fuggveny amellyel szovegal;lomanyba kkirjuk a legrovidebb Hamilton-kor hosszat
{
	ofstream out(inout + "out");

	if (min == MAX)				//ha min == max akkor nem letezik hamilton-kor a grafban
		out << -1 << endl;
	else
		out << min << endl;

	out.close();
}