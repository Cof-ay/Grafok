// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Azonosito: dnim2005
//
// Lab4 2. feladat
//
// Euler - vonal
// Adott egy iranyitott multigraf. Hatarozzunk meg benne egy Euler-vonalat, ha letezik. Az algoritmus legyen iterativ �s fusson linearis idoben!

#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <stack>

using namespace std;

string inout = "lab4_2_5.";

void Beolvas(vector <vector <int> >& graf, int& n, int& m);

void Epit_Elek(const vector<vector <int>>& graf, vector < queue <int> >& elek);

void BeKiFokok(const vector <vector<int>>& graf, vector <int>& be, vector <int>& ki);

void Hierholzer(int ki, vector <queue <int> > elek, vector <int>& vonal);

bool Ellenor(int m, const vector <int>& vonal, const vector <int>& be, const vector <int>& ki);

void Kiir(bool van, const vector <int>& vonal);

void Euler(vector <queue <int> >& elek, int m, const vector <int>& be, const vector <int>& ki);

int main()
{

	vector <vector <int> > graf;
	int n, m;

	Beolvas(graf, n, m);

	vector <queue <int> > elek;
	Epit_Elek(graf, elek);

	vector <int> ki, be;

	BeKiFokok(graf, be, ki);

	Euler(elek, m, be, ki);

	be.clear();
	ki.clear();
	elek.clear();
	graf.clear();

	return 0;
}

void Beolvas(vector <vector <int> >& graf, int& n, int& m)		//beolvassuk a grafot egy szovegallomanybol
{
	ifstream in(inout + "in");

	in >> n >> m;

	graf.resize(n);

	int u, v;
	for (int i = 0; i < m; ++i)
	{
		in >> u >> v;
		u--;	v--;

		graf[u].push_back(v);
	}

	in.close();
}

void Epit_Elek(const vector<vector <int>>& graf, vector < queue <int> >& elek)		//fuggveny amellyel az iranyitott grafbol egy queue-t hasznalo ellistaba felirjuk
{
	elek.resize(graf.size());

	for (int i = 0; i < graf.size(); ++i)
	{
		for (int j = 0; j < graf[i].size(); ++j)
			elek[i].push(graf[i][j]);
	}
}

void BeKiFokok(const vector <vector<int>>& graf, vector <int>& be, vector <int>& ki)	//kiszamoljuk a csucsok be-ki fokait
{
	be.resize(graf.size());
	ki.resize(graf.size());

	for (int i = 0; i < graf.size(); ++i)
	{
		ki[i] = graf[i].size();
		for (int j = 0; j < graf[i].size(); ++j)
		{
			be[graf[i][j]]++;
		}
	}

}

void Hierholzer(int ki, vector <queue <int> > elek, vector <int>& vonal)
{
	stack<int> verem;
	verem.push(ki);			//betesszuk az elso elemet a verembe
	int akt = ki;
	int kov;
	while (!verem.empty())		//addig megyunk amig a verem ures nem lesz
	{
		if (!elek[akt].empty())		//vizsgaljuk, hogy van-e meg "letezo" el az aktualis csucsbol kifele
		{
			verem.push(akt);				//ha igen, akkor az elozo megkapja az aktualis csucs indexet
			kov = elek[akt].front();
			elek[akt].pop();				//toroljuk az elt amin jottunk				//majd betesszuk a verembe az uj aktualis csucsot
			akt = kov;
		}
		else
		{
			vonal.push_back(akt);
			akt = verem.top();
			verem.pop();
		}
	}

}

bool Ellenor(int m, const vector <int>& vonal, const vector <int>& be, const vector <int>& ki)		//fugveny amely ellenorzi, hogy felirt utvonalban egy szabalyos euler vonal
{
	if ((vonal.size() == (m + 1)) && (m != 0))
	{
		if (vonal[0] == vonal[vonal.size() - 1])
		{
			if (be[vonal[0]] == ki[vonal[0]])
			{
				int i = 1;
				bool ok = true;
				while ((i < (vonal.size() - 1)) && ok)
				{
					if (be[vonal[i]] != ki[vonal[i]])
						ok = false;
					i++;
				}

				return ok;
			}
			else
				return false;
		}
		else
		{
			if ((ki[vonal[0]] == be[vonal[0]] - 1) && (ki[vonal[vonal.size() - 1]] == be[vonal[vonal.size() - 1]] + 1))
			{
				int i = 1;
				bool ok = true;
				while ( (i < (vonal.size() - 1)) && ok )
				{
					if (be[vonal[i]] != ki[vonal[i]])
						ok = false;
					i++;
				}

				return ok;
			}
			else
				return false;

		}
	}
	else
		return false;
}

void Kiir(bool van, const vector <int>& vonal)		//fuggveny amely kiirja egy szovegallomanyba az eredmenyt
{
	ofstream out(inout + "out");

	if (van)					//ha letezik Euler-vonal akkor azt kiirjuk
	{
		for (int i = vonal.size() - 1; i >= 0; --i)		//a vonal tombbe forditott sorrendben kerulek a csucsok
			out << vonal[i] + 1 << " ";
		out << endl;
	}

	else						//ha nem letezik akkor a megfelelo uzenet irodik az allomanyba
	{
		out << -1 << endl;
	}
	out.close();
}

void Euler(vector <queue <int> >& elek, int m, const vector <int>& be, const vector <int>& ki)		//csomagolo fuggveny, amely meghivja szukseges fuggvenyeket
{

	bool van = false;			//van-al vizsgaljuk, hogy kaptunk-e euler-vonalat a  grafban
	int kip = 0;
	vector <int> vonal;
	while (!van && (kip < elek.size()))		//addig megyunk amig nem kapunk egy euler vonalat vagy
	{										//amig ki nem probaltuk minden csucsot kiindulasi pontnak
	
		Hierholzer(kip, elek, vonal);
		
		van = Ellenor(m, vonal, be, ki);

		if(!van)
		{
			kip++;
			vonal.clear();
		}
	}

	Kiir(van, vonal);

	if (!vonal.empty())
		vonal.clear();
}

