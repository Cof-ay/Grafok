// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Azonosito: dnim2005
//
// Lab4 4. feladat
//
// Fa atmeroje es kozeppontja
// Adott egy fa, hatarozzuk meg az atmerojet, sugarat es kozeppontjat vagy kozeppontjait linearis idoben!

#include <iostream>
#include <fstream>
#include <vector>
#include <utility>

using namespace std;

string inout = "lab4_4_5.";

void Beolvas(int& n, vector <vector <int>>& graf);

void Meretez(int n, vector <int>& lefele1, vector <int>& lefele2, vector <int>& merre, vector <int>& felfele, vector <int>& ex);

void Lefele12(const vector <vector <int>>& graf, int u, int a, vector <int>& lefele1, vector <int>& lefele2, vector <int>& merre);

void Ex(const vector <vector <int>>& graf, int u, int a, const vector <int>& lefele1, const vector <int>& lefele2, const vector <int>& merre, vector<int>& ex, vector<int>& felfele);

int szamitAtmero(const vector <int>& ex);

int szamitSugar(const vector <int>& ex);

pair<int, int> Kozeppontok(const vector <int>& ex, int sugar);

void Kiir(const vector <int>& ex);

int main()
{
	vector <vector <int> > graf;
	int n;
	vector <int> lefele1, lefele2, merre, felfele, ex;
	Beolvas(n, graf);

	Meretez(n, lefele1, lefele2, merre, felfele, ex);

	Lefele12(graf, 0, 0, lefele1, lefele2, merre);

	Ex(graf, 0, 0, lefele1, lefele2, merre, ex, felfele);

	Kiir(ex);

	felfele.clear();
	ex.clear();
	lefele1.clear();
	lefele2.clear();
	merre.clear();
	graf.clear();
	
	return 0;
}

void Beolvas(int& n, vector <vector <int>>& graf)		//fuggveny amellyel beolvassuk a fat a szovegallomanybol
{
	ifstream in(inout + "in");

	in >> n;
	graf.resize(n);

	int u, v;

	for (int i = 0; i < n - 1; ++i)
	{
		in >> u >> v;
		u--;	v--;

		graf[u].push_back(v);
		graf[v].push_back(u);
	}

	in.close();
}


void Meretez(int n, vector <int>& lefele1, vector <int>& lefele2, vector <int>& merre, vector <int>& felfele, vector <int>& ex)		//fuggveny amelyben lefoglaljuk a felhasznalt vektoroknak a szukseges tarhelyet
{
	lefele1.resize(n);
	lefele2.resize(n);
	merre.resize(n);
	felfele.resize(n);
	ex.resize(n);
}


int szamitAtmero(const vector<int>& ex)		//fuggveny amellyel egy fa atmerojet szamitjuk ki
{
	int max = ex[0];						//maximum kereses az ex tombben
	for (int i = 1; i < ex.size(); ++i)
	{
		if (max < ex[i])
		{
			max = ex[i];
		}
	}

	return max;
}


int szamitSugar(const vector <int>&ex)		//fuggveny amellyel a fa sugarat szamitjuk ki
{
	int min = ex[0];						//min kereses az ex tombben

	for (int i = 1; i < ex.size(); ++i)
	{
		if (ex[i] < min)
		{
			min = ex[i];
		}
	}

	return min;
}

pair<int, int> Kozeppontok(const vector <int>& ex, int sugar)		//fuggveny amellyel meghatarozzuk a fa kozpontja(i)t
{
	pair<int, int> kozep(-1, -1);
	int i = 0;

	while(i < ex.size() && kozep.second == -1)				//kegmeressuk, hogy melyik csucs(ok)nak az excentricitasa egyenlo a sugarral
	{
		if (ex[i] == sugar)
		{
			if (kozep.first == -1)
			{
				kozep.first = i;
			}
			else
			{
				kozep.second = i;
			}
		}
		i++;
	}

	return kozep;
}

void Kiir(const vector <int>& ex)		//fuggevny amellyel kiirajutk egy allomanyba a kert adatokat
{
	ofstream out(inout + "out");

	out << "A fa atmeroje:" << szamitAtmero(ex) << endl;
	
	int sugar = szamitSugar(ex);
	out << "A fa sugara: " << sugar << endl;

	pair<int, int> kozep;
	kozep = Kozeppontok(ex, sugar);

	out << "A fa kozeppontja(i): " << kozep.first + 1;
	if (kozep.second != -1)
	{
		out << " " << kozep.second + 1;
	}
	
	out << endl;

	out.close();
}

void Lefele12(const vector <vector <int>>& graf, int u, int a, vector <int>& lefele1, vector <int>& lefele2, vector <int>& merre)
{													//fuggveny amellyel az excentricitashoz szukszeges lefele1, lefele2 es merre tomboket szamoljuk ki
 	int v, max1= 0, max2 = 0;
	if (graf[u].size() != 1 || a == u)				//csak az elso hivasnal lesz a==u -val (ahol a szulo, u az "a" gyereke)
	{
		for (int i = 0; i < graf[u].size(); ++i)		//bejarjuk u szomszedait
		{
			v = graf[u][i];

			if (v != a)				//ugyelunk, hogy nehogy visszafele menjunk
			{
				Lefele12(graf, v, u, lefele1, lefele2, merre);		//rekurziv meghivas az u sozmsedjara

				if (lefele1[v] + 1 > max1)			//megjegyezzuk a ket maximalis tavolsagot az u szomszedjai kozul
				{
					max2 = max1;
					max1 = lefele1[v] + 1;
					merre[u] = v;					//megjegyezzuk, hogy merre van a leghosszabb ut
				}
				else
				{
					if (lefele1[v] + 1 > max2 && merre[u] != v)
					{
						max2 = lefele1[v] + 1;
					}
				}
			}
		}

		lefele1[u] = max1;
		lefele2[u] = max2;

	}
	else
	{
		lefele1[u] = lefele2[u] = 0;		//<- u level
	}

}

void Ex(const vector <vector <int>>& graf, int u, int a, const vector <int>& lefele1, const vector <int>& lefele2, const vector <int>& merre, vector<int>& ex, vector<int>& felfele)
{															//fuggveny amellyel a fa excentricitasait szamitju ki
	for (int i = 0; i < graf[u].size(); ++i)			//bejarjuk az u szomszedait
	{
		int v = graf[u][i];
		if (v != a)									//ugyelunk, hogy menjunk visszafele
		{
			if (merre[u] == v)
			{
				felfele[v] = 1 + (felfele[u] > lefele2[u] ? felfele[u] : lefele2[u]);		//kiszamoljuk a felfele ertekeket
			}
			else
			{
				felfele[v] = 1 + (felfele[u] > lefele1[u] ? felfele[u] : lefele1[u]);
			}

			Ex(graf, v, u, lefele1, lefele2, merre, ex, felfele);		//rekurziv meghivas a v-re (u gyerekere)
		}
	}

	ex[u] = (lefele1[u] > felfele[u] ? lefele1[u] : felfele[u]);		//meghatarozzuk u excentricitasat
}