// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Azonosito: dnim2005
//
// Lab4 3. feladat
//
// Kritikus ut
// Adott n tevekenyseg es az ezek kozotti fuggosegek.
// Hatarozzuk meg legkevesebb mennyi ido alatt vegezheto el a teljes tevekenysegsorozat, valamint mindegyik tevekenysegre,
// hogy mikor kezdheto el legkorabban es mikor kezdheto el legkesobben anelkul, hogy befolyasolna a teljes sorozat befejezesi idejet.

#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

#define MAX 1000000

using namespace std;

void Beolvas(vector <int>& csucs, int& n, vector <vector <int> >& begraf, vector < vector <int> >& kigraf);

void Fiktiv_Csucsok(vector <vector <int> >& begraf, vector < vector <int> >& kigraf);

void Tombok_Init(int n, vector <int>& t0min, vector <int>& t0max, vector <int>& t1min, vector <int>& t1max);

void Rek_Modositott_Melysegi(const vector < vector < int > >& graf, int p, stack <int>& sorrend, int* volt);

void Topologiai_Rendezes(const vector < vector < int > >& graf, stack <int>& sorrend);

void Topo_Tomb(stack <int>& sorrend, vector <int>& topo);

void Topo(const vector <vector <int> >& graf, vector <int>& topo);

void CPM_csucs(const vector < vector <int> >& begraf, const vector < vector <int> >& kigraf, const vector <int>& csucs, int n, const vector <int>& topo, vector <int>& t0min, vector <int>& t0max, vector <int>& t1min, vector <int>& t1max);

void Kiir(const vector <int>& t0min, const vector <int >& t0max, int ossz);

string inout = "lab4_1_5.";

int main()
 {
	vector <vector <int> > begraf, kigraf;
	vector <int> csucs, topo, t0min, t1min, t0max, t1max;
	int n;

 	Beolvas(csucs, n, begraf, kigraf);

	Fiktiv_Csucsok(begraf, kigraf);

	Tombok_Init(n, t0min, t0max, t1min, t1max);

	Topo(kigraf, topo);

	CPM_csucs(begraf, kigraf, csucs, n, topo, t0min, t0max, t1min, t1max);

	Kiir(t0min, t0max, t1min[n + 1]);

	t1max.clear();
	t0max.clear();
	t1min.clear();
	t0min.clear();
	topo.clear();
	csucs.clear();
	begraf.clear();
	kigraf.clear();

	return 0;
}

void Beolvas(vector <int>& csucs, int& n, vector <vector <int> >& begraf, vector < vector <int> >& kigraf)		//fuggveny amellyel beolvassuk a bemeneti grafot es a csucsok tevekenysegeit
{
	ifstream in(inout + "in");

	in >> n;
	
	csucs.resize(n + 2);				//n+2-re foglalunk helyet, mivel majd be fogunk vezetni ket fiktiv csucsot a grafba
	begraf.resize(n+2);
	kigraf.resize(n+2);

	for (int i = 1; i <= n; ++i)
	{
		in >> csucs[i];
	}

	int j, u, v;

	for (int i = 1; i <= n; ++i)
	{
		in >> j;
		while (j != 0)
		{
			in >> v;						//mivel egy fiktiv kiindulasi csucsot teszunk majd be, ezzert nem kell csokkentenunk a csucsok indexeit
			kigraf[v].push_back(i);			//a grafot ket fele keppen irjuk fel: be- es ki grafba
			begraf[i].push_back(v);			//begrafban tartjuk szamon, hogy milyen csucsok mennek az adott csucsba
											//kigrafban pedig azt, hogy az adott csucs milyen csucsokba tart
			j--;
		}
	}

	in.close();
}

void Fiktiv_Csucsok(vector <vector <int> >& begraf, vector < vector <int> >& kigraf)		//fuggveny amely beteszi a grafba a fiktiv csucsokat
{
	for (int i = 1; i < begraf.size() - 1; ++i)
	{
		if (begraf[i].size() == 0)					//a 0. csucs egy olyan csucs ami olyan csucsokba tart amelyekbe nem ment el eddig
		{
			begraf[i].push_back(0);					//ennek megfeleloen frissitjuk a be- es ki grafot
			kigraf[0].push_back(i);
		}

		if (kigraf[i].size() == 0)					//az n+1. csucs egy olyan csucs amelybe olyan csucsok tartanak amelyekbol eddig nem indult ki el
		{
			kigraf[i].push_back(begraf.size() - 1);	//ennek megfeleloen frissitjuk a be- es ki grafot
			begraf[begraf.size() - 1].push_back(i);
		}
	}
}

void Rek_Modositott_Melysegi(const vector < vector < int > >& graf, int p, stack <int>& sorrend, int* volt)		//modositott melysegi bejaras
{
	if (volt[p] != 2)													//ha nem kettovel jelolt a csucs, azaz meg nem jartuk be teljesen a szomszedait
	{
		volt[p] = 1;													//akkor 1-ssel jeloljuk, jelezve, hogy itt vagyunk
		for (int i = 0; i < graf[p].size(); ++i)							//bejarjuk az aktualis csucs szomszedait
			if (volt[graf[p][i]] == 0)										//ha meg nem latogattuk meg az egyik szomszedjat, akkor arra meghivjuk a modositott melysegi bejarast
			{
				Rek_Modositott_Melysegi(graf, graf[p][i], sorrend, volt);
			}
		volt[p] = 2;													//a csucs szomszedainak bejarast kovetoen a csucsot 2-re allitjuk, hogy a kovetkezokben erre ne lepjen
		sorrend.push(p);												//betesszuk a sorrendbe
	}
}

void Topologiai_Rendezes(const vector < vector < int > >& graf, stack <int>& sorrend)
{
	int* volt = new int[graf.size()] {0};								//eleinte minden csucsot 0-val jelolunk, jelezve, hogy meg nem voltak

	for (int i = 0; i < graf.size(); ++i)								//bejarjuk a grafot
		Rek_Modositott_Melysegi(graf, i, sorrend, volt);

	delete[] volt;
}

void Topo_Tomb(stack <int>& sorrend, vector <int>& topo)
{
	while (!sorrend.empty())
	{
		topo.push_back(sorrend.top());
		sorrend.pop();
	}
}

void Tombok_Init(int n, vector <int>& t0min, vector <int>& t0max, vector <int>& t1min, vector <int>& t1max)	//fuggveny amely inicializalja a felhasznalt tomboket
{
	t0min.resize(n + 2);			//lefoglaljuk nekik a megfelelo mereteket
	t0max.resize(n + 2);
	t1min.resize(n + 2);
	t1max.resize(n + 2);

	for (int i = 0; i < t0max.size(); ++i)		//es feltoltjuk a t(0/1)max tomoboket
	{
		t0max[i] = MAX;
		t1max[i] = MAX;
	}
}

void Topo(const vector <vector <int> >& graf, vector <int>& topo)	//fuggveny amely meghivasaval megkapjuk a graf topologiai sorrendjet
{
	stack <int> sorrend;

	Topologiai_Rendezes(graf, sorrend);			//egy stackbe epul fel a sorrend
	Topo_Tomb(sorrend, topo);					//atirjuk a stacket egy tombbe

}

void CPM_csucs(const vector < vector <int> >& begraf, const vector < vector <int> >& kigraf, const vector <int>& csucs, int n, const vector <int>& topo, vector <int>& t0min, vector <int>& t0max, vector <int>& t1min, vector <int>& t1max)
{
	t0min[topo[0]] = 0;					//inicializaljuk a fiktiv csucsra a t(0/1)min ertekeket
	t1min[topo[0]] = csucs[topo[0]];

	int u;

	for (int i = 1; i < n + 2; ++i)		//bejarjuk a topologiai tombot balrol jobbra
	{
		u = topo[i];
		for (int j = 0; j < begraf[u].size(); ++j)		//bejarjuk azokat a csucsokat amelyek az u-ba mennek
		{
			t0min[u] = (t0min[u] > t1min[begraf[u][j]]) ? t0min[u] : t1min[begraf[u][j]];	//kiszamoljuk, hogy mikor kezdodhet az u tevekenyseg a leghamarabb
		}

		t1min[u] = t0min[u] + csucs[u];		//majd azt, hogy ez a tevekenyseg mikor fejezodhet be a leghamrabb
	}

	t1max[topo[n + 1]] = t1min[topo[n + 1]];						//masodik bejaras elott inicializaljuk a vegso fiktiv csucsra a t(0/1)max ertekeket
	t0max[topo[n + 1]] = t1max[topo[n + 1]] - csucs[topo[n + 1]];

	for (int i = n ; i >= 0; --i)			//elkezdjuk hatulrol bejarni a topologiai tomobt (jobbrol balra)
	{
		u = topo[i];
		for (int j = 0; j < kigraf[u].size(); ++j)		//bejarjuk azokat a csucsokat amelyekbe az u tart
		{
			t1max[u] = t1max[u] < t0max[kigraf[u][j]] ? t1max[u] : t0max[kigraf[u][j]];		//kiszamoljuk, hogy az u teveknyseg mikor fejezodhet be a legkesobb
		}

		t0max[u] = t1max[u] - csucs[u];			//kiszamoljuk, hogy mikor kezdodhte el legkesobb az u tevekenyseg
	}
}

void Kiir(const vector <int>& t0min, const vector <int >& t0max, int ossz)		//fuggveny amely kiirja szovegallomanyba az eredmenyeket
{
	ofstream out(inout + "out");

	out << ossz << endl;			//ossz = t1min[n+1] - a teljes tevekenysegsorozat befelyezesehez szukseges ido

	for (int i = 1; i < t0min.size() - 1; ++i)
	{
		out << t0min[i] << " " << t0max[i] << endl;		//minde csucsra kiirjuk a legkorabbi es legkesobbi idopontokat amikor a tevekenyseg elkezdodhet
	}

	out.close();
}