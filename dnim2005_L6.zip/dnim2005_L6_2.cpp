// Nev: Domokso Nikolette - Beatrice
// Azonosito: dnim2005
// Csoport: 511/2
//
// Lab 6 2.feladat
//
// Maximalis parositas
// Adva van egy n1+n2 csucsu m elu paros graf, hatarozzunk meg benne egy maximalis parositast!

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <set>

using namespace std;

string inout = "lab6_2_1.";

void Beolvas(int& n1, int& n2, int& m, vector<vector<int>>& graf, vector <int>& parok);
void Init_Parok(vector <int>& parok);
int Szelessegi(int n, int n1, vector <vector <int>>& graf, vector <int>& parok, int* p);
void Ut(int k, int* p, vector <int>& ut);
set < pair <int, int> > Edmonds_Karp(int n, int n1, vector < vector <int> >& graf, vector<int>& parok);
void Kiir(const set < pair <int, int> >& elek);

int main()
{
	vector < vector <int> > graf;
	vector <int> parok;
	int n1, n2, m, k;
	set < pair < int, int> > elek;

	Beolvas(n1, n2, m, graf, parok);
	Init_Parok(parok);

	k = n1 + n2 + 2;

	elek = Edmonds_Karp(k,n1, graf, parok);

	Kiir(elek);

	elek.clear();
	graf.clear();
	parok.clear();

	return 0;
}

void Beolvas(int& n1, int& n2, int& m,vector<vector<int>>& graf, vector <int>& parok)		//fuggveny amellyel beolvassuk a paros grafot
{
	ifstream in(inout + "in");

	in >> n1 >> n2 >> m;
	parok.resize(n2+1);			//a parokban fogjuk nyilvantartani az eddigi parokat ; legtobb annyi parositas lehetseges ahany csomopont van a baloldali csoportban

	int k = n1 + n2 + 2;		//k lesz a nagy grafunk merete ; jobboldali csoport + baloldali csoport + szuper forras + szuper nyelo
	graf.resize(k);

	int u, v;

	for (int i = 0; i < m; ++i)				//beolvassuk a grafot mint egy iranyitott graf
	{
		in >> u >> v;
		graf[u].push_back(n1 + v);			//a bal oldali csomopontokhoz hozzaadunk n1-et
	}

	for (int i = 1; i <= n2; ++i)			//bekotjuk a baloldali csomopontokhoz a szupernyelot
	{
		graf[i + n1].push_back(k - 1);
	}

	for (int i = 1; i <= n1; ++i)			//bekotjuk a jobboldali csomopontokhoz a szuperforrast
	{
		graf[0].push_back(i);
	}

	in.close();
}

void Init_Parok(vector <int>& parok)					//fuggveny amellyel inicializaljuk a parositasokat
{
	for (int i = 0; i < parok.size(); ++i)
	{
		parok[i] = -1;
	}
}

int Szelessegi(int n,int n1, vector <vector <int>>& graf, vector <int>& parok, int* p)		//graf szelessegi bejarasat megvalosito fuggveny
{
	bool* volt = new bool[n] {false};
	queue <int> q;
	volt[0] = true;										//beallitjuk a kiinduloponthoz tartozo informaciokat
	q.push(0);											//betesszuk a queue-ba a csucsot
	int u, v;
	while (!q.empty())									//ciklus, amely addig megy amig a queue ki nem urult
	{
		u = q.front();									//u megkapja a queue-bol a FIFO szerkezet szerinti elso elemet
		for (int i = 0; i < graf[u].size(); ++i)			//bejarja ennek a szomszedait
		{
			v = graf[u][i];
			if (v == n - 1)								//vuzsgaljuk, hogy nem-e a szupernyelohoz ertunk
			{
				p[v] = u;								//megjegyezzuk, hogy kin keresztul ertunk el ide
				delete[] volt;
				return 1;
			}

			if (volt[v] == false)					//ha meg nem jartunk az aktualis szomszedon akko az bekerul a queuebe
			{
				volt[v] = true;						//beallitjuk a volt jelzojet
				p[v] = u;							//megjegyezzuk, hogy kin keresztul ertunk el hozza
				q.push(v);
			}


 		}
		q.pop();										//ezt kovetoen kiszedi a bejart csucsot a queue-bol
	}

	delete[] volt;
	return 0;
}


void Ut(int k, int* p, vector <int>& ut)		//fuggveny amellyel rekurzivan visszakeressuk az utat az apasagi (p) tombbol
{
	if (p[k] != k)
	{
		Ut(p[k], p, ut);
	}

	ut.push_back(k);
}

set < pair <int, int> > Edmonds_Karp(int n, int n1, vector < vector <int> >& graf, vector<int>& parok)		//modositott Edmonds Karp algortimus
{
	vector <int> ut;
	int u, v;
	int* p = new int[n] {0 };

	for (int i = 0; i < n; ++i)			//inicializaljuk az apasagi tombot (mindenki onmaga szuleje)
	{
		p[i] = i;
	}

	for (int i = 1; i <= n1; ++i)		//bejarjuk a graf jobb oldalat
	{
		if (graf[i].size() == 1 && parok[graf[i][0] - n1 - 1] == -1)	//nezzuk, hogy van-e olyan csucs amelynek csak egy (meg szabad) szomszedja van
		{
			int seged = graf[i][0];
			parok[graf[i][0] - n1 -1] = i;			//parositjuk a csomopontot a szomszedjaval
			graf[i][0] = 0;							//modositjuk a grafot (rezidualis halokent kezeljuk)
			graf[seged].push_back(i);				//visszamutato el a szomszedbol a jobboldali csomopontba
			int j = 0;
			while (j < graf[0].size() && graf[0][j] != i) j++;
			graf[0].erase(graf[0].begin() + j);			//kiszedjuk a forrasbol erkezo elt a csomopontba
			
			j = 0;
			while (j < graf[seged].size() && graf[seged][j] != n - 1) j++;
 			graf[seged].erase(graf[seged].begin() + j);		//kiszedjuk a szomszed eljei kozul azt amelyk a szupernyelore mutat
			graf[n - 1].push_back(seged);					//visszamutato elt teszunk be a nyelobol a sozmszed csomopontra
		}

 	}

	while (Szelessegi(n,n1, graf, parok, p))			//megyunk ameddgi letezik javitout
	{
		Ut(n-1, p, ut);						//visszakeressuk az utat

		for (int i = 1; i < ut.size(); ++i)
		{
			u = ut[i - 1];
			v = ut[i];
			int j = 0;
			while (j < graf[u].size() && graf[u][j] != v)		//betesszuk a visszamutato eleket
			{
				j++;
			}
			graf[u].erase(graf[u].begin() + j);
			graf[v].push_back(u);

			if (u != 0 && v != (n - 1) && (i % 2 == 0))		//parositjuk a csomopontokat | aaz utbol minden masodik el resze a parositasnak
			{
				parok[v - n1 - 1] = u;
			}
		}

		for (int i = 0; i < n; ++i)				//frissitjuk az apasagi tombot
		{
			p[i] = i;
		}
		ut.clear();			//kiuritjuk az utakat
	}

	set < pair <int, int> > elek;

	for (int i = 0; i < parok.size(); ++i)				//kiszedjuk a parositasokat
	{
		if (parok[i] != -1)
		{
			elek.insert(make_pair(parok[i], i + 1));
		}
	}
	
	delete[] p;
	return elek;				//visszateritjuk a eleket
}

void Kiir(const set < pair <int, int> >& elek)				//fuggveny amellyel kiiratjuk a parositasokat
{
	ofstream out(inout + "out");

	out << elek.size() << endl;

	set <pair <int, int> >::iterator itr;
	for (itr = elek.begin(); itr != elek.end(); itr++)
	{
		out << itr->first << " " << itr->second << endl;
	}

	out.close();
}