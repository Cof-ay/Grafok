// Nev: Domokos Nikolette - Beatrice
// Azonosito: dnim2005
// Csoport: 511/2
//
// Lab6 1. feladat
// 
// Maximalis folyam
// Adott egy n csucsu m elu egyszeru iranyitott folyamhalozat, azzal a tulajdonsaggal, hogy ha letezik (u, v) el, akkor nem letezik (v, u) el.
// Ismerven az s forrast es a t nyelot, allapitsuk meg polinomialis ideju algoritmussal a maximalis folyam mennyiseget es egy minimalis vagatot!

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <unordered_set>

#define MAX 99999

using namespace std;

string inout = "lab6_1_1.";

void Beolvas(int& n, int& m, int& s, int& t, vector < vector <pair <int, int > > >& folyam);
void Rezidualis_Halo(const vector < vector <pair <int, int > > >& folyam, int** halo);
int Szelessegi(int n, int** halo, int* p, int s, int t, vector <int>& sor);
int Edmonds_Karp(int n, int** halo, const vector < vector <pair <int, int > > >& folyam, int s, int t, vector <int>& sor);
void Kiir(int maxf, const vector <int>& sor, const vector < vector <pair <int, int > > >& folyam);

int main()
{
	vector < vector <pair <int, int > > > folyam;
	vector <int> sor;
	int n, m, s, t;
	int** halo;
	int maxf;

	Beolvas(n, m, s, t, folyam);

	halo = new int*[n] {0};
	for (int i = 0; i < n; ++i)
	{
		halo[i] = new int [n] {0};
	}

	Rezidualis_Halo(folyam, halo);

	maxf = Edmonds_Karp(n, halo, folyam, s, t, sor);

	Kiir(maxf, sor, folyam);

	folyam.clear();

	for (int i = n - 1; i >= 0; --i)
	{
		delete[] halo[i];
	}

	delete[] halo;

	return 0;
}


void Beolvas(int& n, int& m, int& s, int& t, vector < vector <pair <int, int > > >& folyam)		//fuggveny amellyel beolvassuk a folyamhalozatot egy szovegallomanybol
{
	ifstream in(inout + "in");
	in >> n >> m >> s >> t;
	s--;	t--;

	folyam.resize(n);

	int u, v, w;
	for (int i = 0; i < m; ++i)
	{
		in >> u >> v >> w;
		u--;	v--;
		folyam[u].push_back(make_pair(v, w));
	}

	in.close();
}

void Rezidualis_Halo(const vector < vector <pair <int, int > > >& folyam, int** halo)		//fuggveny amelyben felepitjuk a rezidualis halot
{
	
	for (int i = 0; i < folyam.size(); ++i)
	{
		for (int j = 0; j < folyam[i].size(); ++j)
		{
			halo[i][folyam[i][j].first] = folyam[i][j].second;		//eleinte a folyamokat 0-nak vesszuk -> a kapacitas kerul be a haloba
		}
	}
}

void Ut(int k, int* p, vector <int>& ut)		//fuggveny amelley rekurzivan visszakeressuk az utat az apasagi tombbol
{
	if (p[k] != k)
	{
		Ut(p[k], p, ut);
	}

	ut.push_back(k);
}

int Min_El(const vector <int>& ut, int** halo)			//fuggveny amellyel megkeressuk a minimalis elet
{
	int min = MAX;
	int u;
	for (int i = 1; i < ut.size(); ++i)			//vegigmegyunk az uton
	{
		u = ut[i - 1];
		if (halo[u][ut[i]] < min)			//es nezzuk a rezidualis halobol, hogy kisebb-e a folyam az aktualis elen mint a min
			min = halo[u][ut[i]];
	}

	return min;
}

int Szelessegi(int n, int** halo, int* p, int s, int t, vector <int>& sor)		//graf szelessegi bejarasat megvalosito fuggveny
{
	bool* volt = new bool[n] {false};
	queue <int> q;
	volt[s] = true;										//beallitjuk a kiinduloponthoz tartozo informaciokat
	q.push(s);											//betesszuk a queue-ba a csucsot
	sor.push_back(s);									//sor-ban tartjuk nyilvan, hogy melyik csucsokat erintettuk a bejaras soran
	int u;
	while (!q.empty())									//ciklus, amely addig megy amig a queue ki nem urult
	{
		u = q.front();									//u megkapja a queue-bol a FIFO szerkezet szerinti elso elemet
			for (int i = 0; i < n; ++i)					//bejarja ennek a szomszedait
			{
				if (halo[u][i] != 0)					//nezzuk, hogy letezik-e ut
				{
					if (i == t)							//nezzuk, hogy nem-e ertunk a nyelohoz
					{
						p[i] = u;						//megjegyezzuk, hogy kin keresztul ertuk el a nyelot
						delete[] volt;
						return 1;
					}

					if (volt[i] == false)				//nezzuk, hogy voltunk-e mar az adott csucson
					{
						volt[i] = true;					//ha nem akkor most mar igen
						p[i] = u;						//megjegyezuk, hogy kin keresztul erkeztunk
						sor.push_back(i);				//betesszuk a sorba a csucsot
						q.push(i);						//betesszuk a queue-ba a csuscot
					}
				}
			}
		q.pop();										//ezt kovetoen kiszedi a bejart csucsot a queue-bol
	}

	delete[] volt;
	return 0;
}

int Edmonds_Karp(int n, int** halo, const vector < vector <pair <int, int > > >& folyam, int s, int t, vector <int>& sor)
{
	int flow = 0;				//eleinte 0 a folyam
	vector <int> ut;
	int min;
	int u, v;
	int* p = new int[n] {0 };

	for (int i = 0; i < n; ++i)			//inicializaljuk az apasagi tombot
	{
		p[i] = i;						//eleinte mindenki a sajat apja
	}

	while (Szelessegi(n, halo, p, s, t, sor))			//megyunk ameddig letezik javitout
	{
		Ut(t, p, ut);					//visszakeressuk az utat
		min = Min_El(ut, halo);			//minimumszamolas az ut-ban levo eleken

		flow += min;					//a flowhoz hozzaadjuk ezt a min-t

		for (int i = 1; i < ut.size(); ++i)		//bejarjuk az utat
		{
			u = ut[i - 1];					
			v = ut[i];
			halo[u][v] -= min;			//modositjuk a rezidualist halot
			halo[v][u] += min;
		}

		for (int i = 0; i < n; ++i)		//visszaallitjuk az apasagitombot
		{
			p[i] = i;
		}
		ut.clear();					//kiuritjuk a sort es a utat
		sor.clear();
	}

	return flow;					//visszateritjuk a maximalis folyamot
}

void Kiir(int maxf, const vector <int>& sor, const vector < vector <pair <int, int > > >& folyam)		//fuggveny amellyel kiiratjuk a maximalis folyamot es a minimalis vagatot
{
	ofstream out(inout + "out");

	out << maxf << endl;

	int ossz = 0;
	for (int i = 0; i < sor.size(); ++i)		//a sorban levo csucsokbol kimeno elek lesznek a minimalis vagatba tartozo elek
	{
		ossz += folyam[sor[i]].size();			//meghatarozzuk ezeknek a szamat
	}
	out << ossz << endl;

	for (int i = 0; i < sor.size(); ++i)		//majd kiiratjuk a konkret eleket
	{
		for (int j = 0; j < folyam[sor[i]].size(); ++j)
			out << sor[i] + 1 << " " << folyam[sor[i]][j].first + 1 << " " << folyam[sor[i]][j].second << endl;
	}

	out.close();
}