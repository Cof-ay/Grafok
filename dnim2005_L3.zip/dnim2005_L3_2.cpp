// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
//
// L3 2. feladat
// 
// Dijkstra algoritmusa
// Adott egy egyszeru iranyitott sulyozott graf es egy kiindulasi csucs. Hatarozzuk meg a kiindulasi csucsbol a tobbibe vezeto legrovidebb utakat O(m log n) bonyolultsagban. 
// Hasznalhatjatok a programozasi nyelvbe beepitett adatszerkezeteket (pl. set, priority_queue), vagy implementalhatjatok a kupac adatszerkezetet.

#include <iostream>
#include <vector>
#include <set>
#include <fstream>

#define INF 999999999999			//inf = vegtelen ; definialjuk mert INT_MAX hasznalataval az osszeadasokkor tulcsordulas lep fel
									//es akkor nem fog helyesen mukodni a porgram
#define ll long long

using namespace std;

string inout = "lab3_2_1.";

void Beolvas(vector < vector < pair <int, int> > >& graf, int& n, int& m, int& s);

void Init(int n, ll* d, int* p);

void Relax(const vector < vector <pair <int, int> > >& graf, int u, ll* d, int* p, set <pair <int, int> >& ismeretlen);

void Dijkstra(const vector < vector <pair <int, int> > >& graf, int s, ll* d, int* p);

void Ut_Kiir(int u, int* p, ofstream& out);

void Kiir(int n, ll* d, int* p, int s);

int main()
{
	vector < vector < pair <int, int> > > graf;
	int n, m, s;

	Beolvas(graf, n, m, s);

	ll* d = new ll[n];
	int* p = new int[n];

	Init(n, d, p);

	Dijkstra(graf, s, d, p);

	Kiir(n, d, p, s);

	delete[] d;
	delete[] p;
	graf.clear();

	return 0;
}

void Beolvas(vector < vector < pair <int, int> > >& graf, int& n, int& m, int& s)		//fuggveny amellyel beolvassuk a grafot szovegallomanybol
{
	ifstream in(inout + "in");

	in >> n >> m >> s;			//s-ben lesz a startpont / kiindulasi csucs
	s--;

	graf.resize(n);
	int u, v, e;

	for (int i = 0; i < m; ++i)
	{
		in >> u >> v >> e;
		u--;	v--;

		graf[u].push_back(make_pair(e,v));		//szomszedsagi listat epitunk fel; a szomszedokat a sullyal egyutt taroljuk, az kerul az elso helyre
	}

	in.close();
}

void Init(int n, ll* d, int* p)			//fuggveny amely inicializalja a d es p tomboket
{
	for (int i = 0; i < n; ++i)
	{
		p[i] = -1;
		d[i] = INF;
	}
}

void Relax(const vector < vector <pair <int, int> > >& graf, int u, ll* d, int *p, set <pair <int, int> >& ismeretlen)
{
	int v, w;
	for (int i = 0; i < graf[u].size(); ++i)		//bejarjuk az u szomszedait
	{
		v = graf[u][i].second;
		w = graf[u][i].first;
		if (d[v] > d[u] + w)					//nezzuk, hogy tudunk-e javitani a szomszedba
		{
			if (d[v] != INF)					//ha lehet es szerepel az ismeretlen tombben a csucs akkor toroljuk a tombbol
			{
				ismeretlen.erase(ismeretlen.find(make_pair(d[v], v)));
			}

			d[v] = d[u] + w;					//frissitjuk az uj tavolsaggal a szomszedot
			p[v] = u;							//megjegyezzuk, hogy melyik csucsbol jottunk
			ismeretlen.insert(make_pair(d[v], v));		//es frissitjuk az ismeretlen listaban a szoszedot (betesszuk az uj tavolsagaval)
		}
		
	}
}

void Dijkstra(const vector < vector <pair <int, int> > >& graf, int s, ll* d, int* p)		//dijkstra algoritmusa a legrovidebb pozitiv utak kiszamolasahoz
{
	set < pair <int, int> > ismeretlen;

	d[s] = 0;									//inicializaljuk a kiindulopont tavolsagat (onmagaba a tavolsag 0)
	ismeretlen.insert(make_pair(0, s));			//betesszuk az ismeretlen tombbe a kezdopontot
	int u;

	while (!ismeretlen.empty())					//amig van olyan csucs aminek nem szamoltunk minimalis tavolsagot
	{
		u = ismeretlen.begin()->second;			//az u megkapja a tombbol a legkisebb tavolsaggal rendelkezo csucspontot
		ismeretlen.erase(ismeretlen.begin());	//toroljuk az elso part a tombbol

		Relax(graf, u, d, p, ismeretlen);		//es relaxalunk az u ponton
	}

}

void Ut_Kiir(int u, int* p, ofstream& out)		//fuggveny amely rekurzivan visszakeresi es kiirja az adot pontba vezeto minimalis utat
{
	if (p[u] != -1)
	{
		Ut_Kiir(p[u], p, out);
	}
	out << u + 1 << " ";
}

void Kiir(int n, ll* d, int* p, int s)			//fuggveny amely kiirja a kert informaciokat egy szovegallomanyba
{
	ofstream out(inout + "out");

	for (int i = 0; i < n; ++i)					
	{
		if (i != s)								//minden nem kiindulasipontra kiirjuk a minimalis utakat es azok hosszat
		{
			if (d[i] == INF)					//vagy azt, hogy nem erhetoek el az adott kiindulasi pontbol
			{
				out << "A legrovidebb ut hossza " << i + 1 << "-ba / be: nem lehet eljutni\n";
				out << "A legrovidebb ut " << i + 1 << "-ba / be: nem lehet eljutni\n";
			}
			else
			{
				out << "A legrovidebb ut hossza " << i + 1 << "-ba / be: " << d[i] << endl;
				out << "A legrovidebb ut " << i + 1 << "-ba / be: ";
				Ut_Kiir(i, p, out);
				out << endl;
			}
			out << endl;
		}
	}

}