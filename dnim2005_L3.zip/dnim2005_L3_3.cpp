// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
//
// L3 3. feladat
// 
// Bellman-Ford algoritmus
// Adott egy egyszeru iranyitott sulyozott graf, mely tartalmazhat negativ sulyokat is es egy kiindulasi csucs. 
// Hatarozzuk meg, hogy a graf tartalmaz-e negativ kort �s ha nem, akkor hatarozzuk meg a legrividebb utakat a tobbi csucsba.

#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
#include <stack>

#define INF 999999999999			//inf = vegtelen ; definialjuk mert INT_MAX hasznalataval az osszeadasokkor tulcsordulas lep fel 
									//es akkor nem fog helyesen mukodni a porgram
#define ll long long

using namespace std;

string inout = "lab3_3_1.";

void Beolvas(vector < vector <pair <int, int> > >& graf, int& n, int& m, int& u);

void Init_d(ll* d, int n);

bool SPFA(const vector < vector <pair <int, int> > >& graf, int s, ll* d, int* p);

void Utak(int s, int u, int* p, ofstream& out);

void Kiir(int n, int s, ll* d, int* p, bool ok);

int main()
{
	vector < vector < pair <int, int> > > graf;
	int n, m, s;

	Beolvas(graf, n, m, s);
	ll* d = new ll[n] {0};
	int* p = new int[n] {0};
	bool ok;
	Init_d(d, n);

	ok = SPFA(graf, s, d, p);
	
	Kiir(n, s, d, p, ok);

	delete[] d;
	delete[] p;
	graf.clear();

	return 0;
}

void Beolvas(vector < vector <pair <int, int> > >& graf, int& n, int& m, int& s)		//fuggveny amellyel beolvassuk egy szovegallomanybol a grafot es felepitjuk a szomszedsagi matrixat
{
	ifstream in(inout + "in");

	in >> n >> m >> s;
	s--;
	graf.resize(n);

	int x, y, z;

	for (int i = 0; i < m; ++i)					//felepitjuk a szomszedsagi matrixot a beolvasas kozben
	{
		in >> x >> y >> z;
		x--; y--;

		graf[x].push_back(make_pair(y,z));		//paireken az elso lesz a szomszed, a masodik pedig a suly
	}

	in.close();
}

void Init_d(ll* d, int n)				//inicializaljuk a d tombbot
{
	for (int i = 0; i < n; ++i)
		d[i] = INF;
}


bool SPFA(const vector < vector <pair <int, int> > >& graf, int s, ll* d, int* p)		//Bellman-Ford algortimusa (Shortest Path Faster Algorithm)
{
	d[s] = 0;					//inicializaljuk a kiindulopont tavolsagat
	queue <int> sor;
	int u = -1;
	bool* sorban = new bool[graf.size()]{ false };		//bool tomb amivel vizsgaljuk, hogy melyik csucs talalhato jelenleg a sorban
	int* javitva = new int[graf.size()]{ 0 };			//tomb amivel szamitjuk a javitasok szamat
	sor.push(s);								//betesszuk a sorba a kiindulasi csucsot

	while (!sor.empty())							//megyunk amig a sor nem lesz ures
	{
		u = sor.front();						//u megkapja a sor elso tagjat
		sor.pop();								//toroljuk a kivett tagot
		sorban[u] = false;						//jelezzuk, hogy mar nincs a sorban a kivett csucs

		for (int i = 0; i < graf[u].size(); ++i)		//bejarjuk az u szomszedait
		{
			if (d[graf[u][i].first] > d[u] + graf[u][i].second)		//vizsgaljuk, hogy az u-bol lehet-e javitani a  a szomszedjaba
			{
				d[graf[u][i].first] = d[u] + graf[u][i].second;		//frissitjuk a tavolsagot a szomszedba
				p[graf[u][i].first] = u;							//megjegyezzuk, hogy honann jottunk
				if (sorban[graf[u][i].first] == false)				//nezzuk, hogy a szomszed nincs-e a sorban
				{
					sor.push(graf[u][i].first);						//ha nincs, akkor betesszuk
					sorban[graf[u][i].first] = true;				//jelezzuk, hogy ott van
					++javitva[graf[u][i].first];					//ez azt jelenti, hogy sikerult javitani


					if (javitva[graf[u][i].first] >= graf.size())		//ha egy csucson tobbet javitottunk mint ahany csucs van, akkor az azt jelenti, hogy van egy negativ kor a grafban
					{
						//cout << javitva[graf[u][i].first];
						return false;								//ekkor leallitjuk az algoritmust
					}
				}
			}

		}
	}
	return true;				//sikeres futas eseten (nem volt negativ kor) igaz erteket teritunk vissza
}

void Utak(int s, int u, int* p, ofstream& out)		//fuggveny amellyel visszakeressuk es kiiratjuk egy pontba vezeto utat
{
	stack <int> ut;					//egy veremben/stackben epitjuk fel az utat
	ut.push(u);						//betesszuk a vegpontot
	int z, v = -1;
	z = u;
	while (z != s)					//megyunk amig el nem erkezunk a startcsucshoz
	{
		v = p[z];					//v megkapja a z elotti csucsot
		ut.push(v);					//betesszuk a v-t a verembe
		z = v;						//z megkapja a v-t
	}

	out << "A legrovidebb ut " << u + 1 << "-ba/be: ";
	while (!ut.empty())				//a verem elemeinek kiiratasaval megkapjuk az s-bol u-ba vezeto utat
	{
		out << ut.top() + 1 << " ";
		ut.pop();
	}
	out << endl;
}

void Kiir(int n, int s, ll* d, int* p, bool ok)			//fuggveny amely kiiratja egy szovegallomanyba egy pontobol minden pontba a minimalis utakat es azok hosszat
{
	ofstream out(inout + "out");

	if (ok)
	{
		for (int i = 0; i < n; ++i)
			if (i != s)								//minden nem startcsucsra kiirjuk a megfelelo uzeneteket
			{
				if (d[i] == INF)					//ha egy csucsba a tavolsag vegtelen, akkor oda nem lehet eljutni az s pontbol
				{
					out << "A legrovidebb ut hossza " << i + 1 << "-ba/be: nem lehet eljutni\n";
					out << "A legrovidebb ut " << i + 1 << "-ba/be : nem lehet eljutni\n";
				}
				else
				{
					out << "A legrovidebb ut hossza " << i + 1 << "-ba/be: " << d[i] << endl;		//kulonben kiirjuk a tavolsagot es az utat
					Utak(s, i, p, out);
				}
				out << endl;
			}
	}
	else
	{
		out << "Van negativ kor.\n";
	}

	out.close();
}