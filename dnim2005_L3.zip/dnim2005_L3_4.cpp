// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
//
// L3 4. feladat
// 
// Roy-Floyd-Warshall algoritmus
// Adott egy iranyitott sulyozott graf szomszedsagi matrixa, valamint egy kiindulasi es erkezesi csucs. 
// Hatarozzuk meg graf a tavolsagi matrixat es a ket csucs kozotti legrovidebb utat!

#include <iostream>
#include <fstream>
#include <vector>
#include <limits>
#include <stack>

#define INF 99999999999			//inf = vegtelen ; definialjuk mert INT_MAX hasznalataval az osszeadasokkor tulcsordulas lep fel
								//es akkor nem fog helyesen mukodni a porgram
#define ll long long
#define MAX_DIS 2000000000

using namespace std;

string inout = "lab3_4_1.";

void Beolvas(int**& matrix, int& n, int& s, int& e);

void Init_P(int** matrix, int** p, int n);

bool RFW_DIST(int** matrix, int n, ll** d, int** p);

void RFW_Ut(stack<int>& ut, int** p, int n, int s, int e);

void Kiir(ll** d, stack <int>& ut, int n, int s, int e, bool ki, bool l_ut);

int main()
{
	int n, s, e;
	int** matrix;

	Beolvas(matrix, n, s, e);

	ll** d;
	int** p;
	stack <int> ut;
	d = new ll* [n];
	p = new int* [n] {0};

	for (int i = 0; i < n; ++i)
	{
		d[i] = new ll[n];
		p[i] = new int[n] {0};
	}

	Init_P(matrix, p, n);

	bool ki = RFW_DIST(matrix, n, d, p);		//ki-vel vizsgaljuk, hogy sikeresen lefutott-e a fuggveny
	bool l_ut = true;							//l_ut-vel jelezzuk, hogy letezik-e ut s es e kozott

	if (ki)
	{
		if (d[s][e] < MAX_DIS)						//ha a tavolsagmatrix felepitese utan s es e kozott a tavolsag meghaladja a MAX_DIS-t akkor az azt jelenti, hogy a ket csucs kozott nem letezik ut
		{
			RFW_Ut(ut, p, n, s, e);
		}
		else
			l_ut = false;

	}

	Kiir(d, ut, n, s, e, ki, l_ut);

	for (int i = n-1; i > 0; --i)
	{
		delete[] matrix[i];
		delete[] p[i];
		delete[] d[i];
	}

	delete[] matrix;
	delete[] p;
	delete[] d;

	return 0;
}

void Beolvas(int**& matrix, int& n, int& s, int& e)		//fuggveny amellyel beolvassuk egy allomanybol a sulyozott matrixot
{
	ifstream in(inout + "in");
	
	in >> n >> s >> e;

	matrix = new int* [n];

	for (int i = 0; i < n; i++)
	{
		matrix[i] = new int[n];
	}

	s--;	e--;


	for(int i = 0; i < n; ++i)
		for (int j = 0; j < n; ++j)
		{
			in >> matrix[i][j];
		}

	in.close();
}

void Init_P(int** matrix, int** p, int n)		//inicializaljuk a p 2 dimenzios tombot
{
	for(int i = 0; i < n; ++i)
		for (int j = 0; j < n; ++j)
		{
			if (matrix[i][j] != 0)				//ha van ut i-bol j-be akkor a p[i][j] megkapja az i-t (mert az i-bol megy a j-be)
				p[i][j] = i;
		}
}

bool RFW_DIST(int** matrix, int n, ll** d, int** p)		//Roy-Floyd-Warshall modositott algoritmus
{
	for (int i = 0; i < n; ++i)			//inicializaljuk a d matrixot
	{
		for (int j = 0; j < n; ++j)
		{
			if (matrix[i][j] == 0)
			{
				d[i][j] = INF;			//ha i es j kozott nincs el akkor a d matrixba a megfelelo indexekre 'vegtelent' teszunk
			}
			else
				d[i][j] = matrix[i][j];		//kulonben az i es j kozotti elek sulyat kapja meg
		}
		d[i][i] = 0;					//az atlokra 0-at helyezunk
	}

	for (int k = 0; k < n; ++k)
	{
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				if (d[i][j] > (d[i][k] + d[k][j]))		//vizsgaljuk, hogy lehet-e javitani az i es j kozotti uton a k-n keresztul
				{
					d[i][j] = d[i][k] + d[k][j];		//ha igen akkor frissitjuk az ertekeket
					p[i][j] = p[k][j];					//valamint feljegyezzuk, hogy honnan erkeztunk
				}

				if (i == j && d[i][j] < 0)				//kozben figyelunk a foatlora; ha negativ ertek kerul be a foatlora akkor az azt jelenti, hogy negativ kor van a grafban
				{
					return false;						//ekkor leallitjuk az algortimust, az hamis erteket fog visszateriteni
				}
			}
		}
	}

	return true;										//helyes futas eseten (ha nem volt negativ kor) akkor igaz erteket teritunk vissza
}

void RFW_Ut(stack<int>& ut, int** p, int n, int s, int e)		//fuggveny amellyel felirjuk ket csucs kozotti utat
{
	int l = e;
	ut.push(e);
	while (l != s)
	{
		l = p[s][l];
		ut.push(l);
	}
	
}

void Kiir(ll** d, stack <int>& ut, int n, int s, int e, bool ki, bool l_ut)			//fuggveny amely kiiratja egy allomanyba a megfelelo uzeneteket
{
	ofstream out(inout + "out");
	if (ki)														//ha a ki-nek igaz erteke van akkor a grafban nem volt negativ kor
	{
		for (int i = 0; i < n; ++i)								//kiiratjuk a minimalis tavolsagi matrixot
		{
			for (int j = 0; j < n; ++j)
			{
				if (d[i][j] > MAX_DIS)
					out << 0 << " ";
				else
					out << d[i][j] << " ";
			}
			out << endl;
		}

		if (l_ut)										//vizsgaljuk, hogy letezik-e ut a ket csucs kozott
		{
			while (!ut.empty())
			{
				out << ut.top() + 1 << " ";
				ut.pop();
			}

			out << endl;
		}
		else
		{
			out << "Nem letezik ut a ket csucs kozott\n";		//ha nincs, akkor kiirjuk a megfelelo uzenetet
		}
	}
	else
	{
		out << "Van negativ kor\n";						//ha a ki-nek hamis erteke van akkor votl negativ kor es kiiratjuk a megfelelo uzenetet
	}

	out.close();
}