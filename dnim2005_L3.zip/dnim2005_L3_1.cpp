// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
//
// L3 1. feladat
//
// Moore algoritmusa
// Adott egy egyszeru iranyitott sulyozatlan graf es egy kiindulasi csucs. Hatarozzuk meg a kiindulasi csucsbol a tobbibe vezeto legrovidebb utakat.

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

string inout = "lab3_1_1.";

void Beolvas(vector <vector <int> >& graf, int& n, int& m, int& u);

void init(int* d, int n);

void Moore(const vector <vector <int> >& graf, int u, int* d, int* p);

void Utak_Ki(int* ut, int k, int v, ofstream& out);

void Moore_Utak(int* d, int* p, int u, int n);

int main()
{
	vector <vector <int> > graf;
	int n, m, u;
	Beolvas(graf, n, m, u);

	int* d = new int[n];
	int* p = new int[n];

	init(d, n);

	Moore(graf, u, d, p);
	Moore_Utak(d, p, u, n);

	graf.clear();
	delete[] d;
	delete[] p;

	return 0;
}

void Beolvas(vector <vector <int> >& graf, int& n, int& m, int& u)		//fuggveny amellyel beolvassuk egy szovegallomanybol es felepitjuk a graf szomszedsagi listajat
{
	ifstream in(inout + "in");
	in >> n >> m >> u;						//u - a kiindulasi pont
	u--;
	graf.resize(n);
	int p, q;

	for (int i = 0; i < m; ++i)
	{
		in >> p >> q;
		p--; q--;

		graf[p].push_back(q);
	}

	in.close();
}

void init(int* d, int n)			//fuggveny amellyel inicializaljuk a d es ut tomboket
{
	for (int i = 0; i < n; ++i)
	{
		d[i] = -1;
	}
}

void Moore(const vector <vector <int> >& graf, int u, int* d, int* p)		//Moore algoritmusa a minimalis utak kiszamolasahoz
{
	d[u] = 0;					//inicializaljuk a kiindulasipont tavolsagat
	queue <int> sor;
	sor.push(u);				//betesszuk a kiindulasipontot egy fifo listaba / varakozasi sorba
	int x;

	while (!sor.empty())		//addig megyunk amig a sor nem lesz ures
	{
		x = sor.front();		//x megkapja az sor elso elemet
		sor.pop();				//azt toroljuk

		for (int i = 0; i < graf[x].size(); ++i)		//majd bejarjuk az x szomszedait
		{
			if (d[graf[x][i]] == -1)			//nezzuk, hogy egy szomszedra volt-e mar szamolva tavolsag
			{
				d[graf[x][i]] = d[x] + 1;		//a szomszed megkapja az x tavolsagat + 1
				p[graf[x][i]] = x;				//megjegyezzuk, hogy honnan jottunk
				sor.push(graf[x][i]);			//betesszuk a szomszedot a sorba
			}
		}
	}

}

void Utak_Ki(int* ut, int k, int v, ofstream& out)			//fuggveny amely a megadott szovegallomanyba iratja ki az utat es annak hosszat
{
	out << "A legrovidebb ut hossza " << v + 1 << "-ba/be: " << k << endl;
	out << "A legrovidebb ut " << v + 1 << "-ba/be: ";

	for (int i = 0; i <= k; ++i)
		out << ut[i] + 1 << " ";
	out << endl;

	out << endl;
}

void Moore_Utak(int* d, int* p, int u, int n)		//fuggveny amely kiiratja minden csucsba vezeto utat
{
	ofstream out(inout + "out");

	int k;
	for (int i = 0; i < n; ++i)
	{
		if (i != u)						//minden, nem kiindulasicsucsra megtortenik
		{
			k = d[i];					//k - ban lesz az ut hossza
			if (k >= 0)						//vizsgaljuk,hogy a k negativ-e (vagyis letezik ut)
			{	
				int* ut;
				ut = new int[k + 1];
				ut[0] = u;					//ut[0]-ba kerul az ut kiindulasi pontja
				ut[k] = i;					//ut[k]-ba kerul az ut vegpontja
				while (k > 0)				//amig van ut visszakeressuk a p tomb segitesegevel az utat
				{
					ut[k - 1] = p[ut[k]];
					--k;
				}
				Utak_Ki(ut, d[i], i, out);		//kiiratjuk az utat
				delete[] ut;					//felszabaditjuk az ut-ak tombot
			}
			else
			{
				out << "A legrovidebb ut hossza " << i + 1 << "-ba/be: nem lehet eljutni\n";		//ha nem letezik ut, akkor kiirjuk a megfelelo uzeneteket
				out << "A legrovidebb ut " << i + 1 << "-ba/be: nem lehet eljutni\n\n";
			}

		}
	}

	out.close();
}

