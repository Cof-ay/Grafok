// Nev : Domokos Nikolette - Beatrice
// Csoport : 511/2
// Lab2 2.feladat
// Adott egy iranyitatlan graf n csuccsal es m ellel (1 <= n <= 1 000 000, 1 <= m <= 5 000 000). 
// Hatarozzuk meg a benne talalhato hidakat, elvago csucsokat �s a graf ketszeresen osszefuggo komponenseit linearis algoritmussal!

#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

string inout = "lab2_2_5.";

int ido = -1;

struct el
{
	int u, v;
};

void Beolvas(vector <vector <int> >& graf, int& n, int& m);

void Init_Belep(int* belep, int n);

void Tarjan_BC(const vector <vector <int> >& graf, int v, int szulo, vector <el>& hidak, vector <int>& elvagok, stack <el>& verem, int* belep, int* low, vector <vector <el> >& komp, int& komp_db);

void Kiir(const vector <el>& hidak, vector <int>& elvagok, vector <vector <el> >& komp);

int main()
{
	vector <vector <int> > graf;
	int n, m;

	Beolvas(graf, n, m);

	vector <el> hidak;
	vector <int> elvagok;
	stack <el> verem;
	int* belep = new int[n];
	int* low = new int[n] {0};
	vector <vector <el> > komp;
	int komp_db = -1;

	Init_Belep(belep, n);

	Tarjan_BC(graf, 0, -1, hidak, elvagok, verem, belep, low, komp, komp_db);

	Kiir(hidak, elvagok, komp);

	delete[] belep;
	delete[] low;
	hidak.clear();
	elvagok.clear();
	komp.clear();
	graf.clear();

	return 0;
}

void Beolvas(vector <vector <int> >& graf, int& n, int& m)		//beolvassuk az iranyitatlan grafot egy szovegallomanybol
{
	ifstream in(inout + "in");
	in >> n >> m;
	graf.resize(n);

	int u, v;

	for (int i = 0; i < m; ++i)
	{
		in >> u >> v;
		u--;	v--;

		graf[u].push_back(v);
		graf[v].push_back(u);
	}

	in.close();
}

void Init_Belep(int* belep, int n)				//fuggveny amellyel inicializaljuk a belep tombot
{
	for (int i = 0; i < n; ++i)
		belep[i] = -1;
}

void Tarjan_BC(const vector <vector <int> >& graf, int v, int szulo, vector <el>& hidak, vector <int>& elvagok, stack <el>& verem, int* belep, int* low, vector <vector <el> >& komp, int& komp_db)
{																//tarjan biconnect algoritmusa, amivel megkerssuk a grafban a hidakat, elvago csucsokat es a ketszeresen osszefuggo komponenseket
	ido++;
	belep[v] = ido;												//megjegyezzuk, hogy mikor leptunk az aktualis csucshoz
	low[v] = ido;
	int gyerek = 0;											//gyerekkel tartjuk szamon, hogy hany "leszarmazotja van"
	bool elvago = false;									//ellenor, amivel az elvago csucs letet tartjuk szamon

	for (int i = 0; i < graf[v].size(); ++i)				//bejarjuk az aktualis csucs szomszedait
	{
		el seged = { v, graf[v][i] };						//seged elbe lementjuk az aktualis el es az egyik gyerekevel alkotott elt

		if (belep[graf[v][i]] == -1)						//vizsgaljuk, hogy jartunk-e mar ennel a "gyereknel" maskor
		{
			verem.push(seged);								//ha nem, akkor a seged elet a verembe tesszuk
			gyerek++;										//noveljuk az aktualis csucs gyerekeinek szamat
			Tarjan_BC(graf, graf[v][i], v, hidak, elvagok, verem, belep, low, komp, komp_db);		//meghivjuk a fuggvenyt rekurzivan. a "gyerek" csucs lesz az uj aktualis es, a szulo csucs pedig a szulo
			low[v] = low[graf[v][i]] < low[v] ? low[graf[v][i]] : low[v];							//aktualis csucs lowja megkapja a gyerek low-jat ha az kisebb mint az ove

			if (low[graf[v][i]] >= belep[graf[v][i]])			//vizsgaljuk, hogy a seged elunk egy hid-e
			{
				hidak.push_back(seged);
			}

			if (low[graf[v][i]] >= belep[v])				//vizsgaljuk, hogy az aktualis csucs elvago csucs-e
			{
				elvago = true;
				++komp_db;
				int last = 0;
				
				komp.resize(komp_db + 1);				//ha igen, akkor ez azt jelenti, hogy a veremben levo elek egy resze egy ketszeresen osszefuggo komponensben vannak
				
				if (verem.empty() == false)				
				{
					komp[komp_db].push_back(verem.top());
					verem.pop();
				}

				while ((verem.empty() == false) && (komp[komp_db][last].u != seged.u && komp[komp_db][last].v != seged.v))
				{
					komp[komp_db].push_back(verem.top());					//egy komponenshez fognak tartozni azok az elek amelyek a veremben a seged el felett vannak
					verem.pop();
					last++;
				}
			}
			
		}
		else
		{
			if ((graf[v][i] != szulo) && (belep[graf[v][i]] < belep[v]))
			{
				verem.push(seged);
				low[v] = belep[graf[v][i]] < low[v] ? belep[graf[v][i]] : low[v];
			}
		}


	}

	if (((szulo != -1) && elvago) || ((szulo == -1) && (gyerek > 1)))		//vizsgaljuk, hogy az aktualis csucs elvago csucs
	{
		elvagok.push_back(v);
	}

}

void Kiir(const vector <el>& hidak, vector <int>& elvagok, vector <vector <el> >& komp)		//fuggveny amely kiiratja egy szovegallomanyba a graf kert reszeit
{
	ofstream out(inout + "out");

	out << "Hidak szama: " << hidak.size() << endl;
	for (int i = 0; i < hidak.size(); ++i)
	{
		out << hidak[i].u + 1 << " " << hidak[i].v + 1 << endl;
	}
	out << endl;

	out << "Elvago csucsok szama: " << elvagok.size() << endl;
	for (int i = 0; i < elvagok.size(); ++i)
	{
		out << elvagok[i] + 1 << endl;
	}
	out << endl;

	out << "Ketszeresen osszefuggo komponensek szama: " << komp.size() << endl;
	for (int i = 0; i < komp.size(); ++i)
	{
		out << endl << i + 1 << ". komponens" << endl;
		for (int j = 0; j < komp[i].size(); ++j)
		{
			out << komp[i][j].u + 1 << " " << komp[i][j].v + 1 << endl;
		}
	}

	out.close();
}