// Nev : Domokos Nikolette - Beatrice
// Csoport : 511/2
// Lab2 1. feladat
// Adott egy logikai kifejezes a kovetkezo formaban: (v1 VAGY v2) ES (v3 VAGY v4) ES ... ES (v2m-1 VAGY v2m), 
// ahol vi egy aj (j = 1..n) logikai valtozo vagy annak a tagadasa (1 <= m <= 100 000). Hatarozzuk meg, hogy tudunk-e ugy erteket adni az aj logikai valtozoknak, 
// hogy a logikai kifejezes erteke IGAZ legyen. Ha igen, adjunk meg egy lehetseges megoldast. Hasznaljunk linearis ideju algoritmust! 

#include <iostream>
#include <vector>
#include <fstream>
#include <stack>

using namespace std;

string inout = "lab2_1_1.";

void Beolvas(vector <vector <int> >& graf, int& n, int& m);

void Init_Belep(int* belep, int n);

int SCC(const vector <vector <int> >& graf, int n, int m, int* komp, int* low);

void Tarjan_SC(const vector <vector <int> >& g, int m, int v, int& ido, int* belep, int* low, stack <int>& s, bool* vermen, int& komp_db, int* komp, bool* volt);

bool Van_e_Megoldas(int* komp, int n);

void Megoldas(int* komp, int n, int komp_db, ofstream& out);

int main()
{
	vector <vector <int> > graf;
	int n, m;

	Beolvas(graf, n, m);

	int* komp = new int[2 * n];
	int* low = new int[2 * n];

	int komp_db;

	komp_db = SCC(graf, n, m, komp, low);

	ofstream out(inout + "out");

	if (Van_e_Megoldas(komp, n))
	{
		Megoldas(komp, n, komp_db, out);
	}
	else out << "Nincs megoldas\n";


	delete[] low;
	delete[] komp;
	graf.clear();

	out.close();

	return 0;
}

void Beolvas(vector <vector <int> >& graf, int& n, int &m)
{
	ifstream in(inout + "in");
	in >> n >> m;

	graf.resize(2 * n + 1);

	int v, u;

	for (int i = 0; i < m; ++i)
	{
		in >> u >> v;																				//pl : n = 4: 1  2  3  4 -1 -2 -3 -4 - minek felelnek meg
																									//		      0  1  2  3  4  5  6  7 - indexeles
		graf[(u < 0 ? u * (-1) - 1 : u + n - 1)].push_back(v < 0 ? v*(-1) + n - 1 : v - 1);			
		graf[(v < 0 ? v * (-1) - 1 : v + n - 1)].push_back(u < 0 ? u*(-1) + n - 1: u - 1);
		
	}

	in.close();
}

void Init_Belep(int* belep, int n)
{
	for (int i = 0; i < 2 * n; ++i)
		belep[i] = -1;
}

void Tarjan_SC(const vector <vector <int> >& g, int m, int v, int& ido, int* belep, int* low, stack <int>& s, bool* vermen, int& komp_db, int* komp, bool* volt)
{
	ido++;									//noveljuk az idot
	belep[v] = ido;							//majd lementjuk, hogy melyik idopillantaban latogatjuk meg az aktualis csucsot
	low[v] = ido;
	vermen[v] = true;						//megjegyezzuk,hogy ezt a csucsot betettuk a verembe
	s.push(v);
	volt[v] = true;

	for (int i = 0; i < g[v].size(); ++i)			//bejarjuk az aktualis csucs szomszedait
	{
		if (belep[g[v][i]] == -1)					//keresunk egy olyat amin meg nem voltunk
		{
			Tarjan_SC(g, m, g[v][i], ido, belep, low, s, vermen, komp_db, komp, volt);			//es azt meglatogatjuk
			low[v] = low[v] < low[g[v][i]] ? low[v] : low[g[v][i]];						//majd az aktualis csucs-ot a minimalis low ertek fogja jellemezni
		}
		else
		{
			if ((belep[g[v][i]] < belep[v]) && vermen[g[v][i]])							//ha nincs nem meglatogatott szomszed es a szomszed belepesi erteke kisebb mint az aktualis csucse es mar a veremben van
			{
				low[v] = low[v] < low[g[v][i]] ? low[v] : low[g[v][i]];					//akkor az aktualis csucs low-ja a ketto kozul a kisebb low-t kapja meg
			}
		}
	}

	if (low[v] == belep[v])									//ha a low es a belepes megegyezik ES letezik legalabb ket el
	{
		komp_db++;														//akkor noveljuk az erosen osszefuggo komponensek szamat
		while (!s.empty() && (belep[s.top()] >= belep[v]))				//egy ciklussal addig megyunk amig a verem ki nem urult vagy emddgi a verem tetejen levo csucsnak a belepese kisebb nem lesz mint az aktualis csucse
		{
			komp[s.top()] = komp_db;
			vermen[s.top()] = false;										//mivel kiszedjuk a verem tetejerol a tagot, ezert a vermen tombot is allitjuk
			s.pop();
		}
	}
}

int SCC(const vector<vector <int> >& graf, int n, int m, int* komp, int* low)		//fuggveny amivel megszamoljuk a graf erosen osszefuggo komponenseit
{
	int* belep = new int[2*n];
	Init_Belep(belep, n);

	bool* vermen = new bool[2*n] {false};
	bool* volt = new bool[2*n] {false};
	int komp_db = 0, ido = -1;

	stack <int> s;

	for (int i = 0; i < 2*n; ++i)								//bejarjuk a teljes felepitett grafot 
	{
		if (volt[i] == false)
		{
			Tarjan_SC(graf, m, i, ido, belep, low, s, vermen, komp_db, komp, volt);
		}
	}

	delete[] belep;
	delete[] vermen;
	delete[] volt;

	return komp_db;									//a fuggveny a komponensek szamat fogja visszateriteni

}

bool Van_e_Megoldas(int* komp, int n)			//fuggveny amely megnezi, hogy letezik-e megoldas az adott grafra
{
	bool van = true;
	int i = 0;

	while ((i < n) && van)					//bejarjuk a graf csomopontjainak a felet (a pozitiv szammal jelolteket)
	{
		if (komp[i] == komp[i + n])			//vizsgaljuk, hogy az ellentetjevel ugyanabban a komponensben van-e
			van = false;					//ha igen, akkor nincs megoldasa a grafnak
		i++;
	}

	return van;
}

void Megoldas(int* komp, int n, int komp_db, ofstream& out)			//fuggveny amely kiiratja egy szovegallomanyba a megoldast
{
	bool* megoldas = new bool[n];

	for (int i = 0; i < n; ++i)						//bejarjuk a pozitiv csomopontokat (1-tol n-ig) / (0-tol (n-1)-ig)
		if (komp[i] > komp_db / 2)					//ha a csomopont egy a komponens darabszam felenel nagyobb komponenshez tartozik, akkor az azt jelenti, hogy az a grafnak az "elejen" helyezkedik el
			megoldas[i] = 0;						//es ezert annak hamis erteket adunk
		else
			megoldas[i] = 1;						//ellenkezo esetben igazat

	for (int i = 0; i < n; ++i)	
		out << megoldas[i] << endl;					//vegul kiiratjuk a megoldast a szovegallomanyba

	delete[] megoldas;
}