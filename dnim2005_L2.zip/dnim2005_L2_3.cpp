// Nev : Domokos Nikolette - Beatrice
// Csoport : 511/2
// Lab2 3.feladat
// Adott egy n csucsu graf, melynek kezdetben minden csucsa izolalt (1 <= n <= 1 000 000). Ebben a grafban ket tipusu muveletet kell elvegeznunk:

// HOZZAAD(u, v) : hozzaadja a grafhoz az{ u, v } iranyitatlan elet
// ELERHETO(u, v) : IGAZ - at terit vissza, ha u �s v ugyanabban az osszefuggo komponensben talalhatoak

// Irjatok algoritmust, mely a leheti leghatekonyabban valositja meg a fenti muveleteket.

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

string inout = "lab2_3_1.";

class Graf
{
public:
	Graf();
	~Graf() { delete[] szulo; delete[] halmazok; };

	void Hozzad(int u, int v);
	bool Elerheto(int u, int v);

private:
	int* szulo;
	int* halmazok;
	int n, k;

	bool Kotott(int u);
	int Keres(int u);
	bool Kozos(int u, int v);
};

int main()
{
	Graf G;

	return 0;
}

Graf::Graf()							//a bemeneti szovegallomanybol beolvasva az utasitasokat helyben elvegezzuk es az eredmenyt beiratjuk a kimeneti szovegallomanyba
{
	string utasitas;
	int u, v;

	ifstream in(inout + "in");
	ofstream out(inout + "out");

	in >> n >> k;

	szulo = new int[n];
	halmazok = new int[n];

	for (int i = 0; i < n; ++i)				//eleinte minden csomopont szulojet -1 allitjuk, mivel ezek izolalt pontok
	{
		szulo[i] = -1;
		halmazok[i] = 1;					//es minden csucspontbol kiindulo halmaz hossza 1
	}

	for (int i = 0; i < k; ++i)				//beolvassuk az utasitasokat
	{
		in >> utasitas >> u >> v;		
		u--;	v--;

		if (utasitas == "ELERHETO")
		{
			out << Elerheto(u, v) << endl;
		}
		else
			if (utasitas == "HOZZAAD")
			{
				Hozzad(u, v);
			}
			else
			{
				out << "Hibas utasitas\n";
			}
	}

	out.close();
	in.close();

}

void Graf::Hozzad(int u, int v)				//hozzad a grafhoz egy az u-v elt
{
	if (!Kozos(u, v))						//vizsgaljuk, hogy nem-e tartoznak mar egy komponenshez
	{
		if (!Kotott(u) && !Kotott(v))			//ha nem, akkor vizsgaljuk, hogy melyiknek tartozik mar egy komponenshez
		{
			szulo[u] = v;												//ha mind a ketto sabad akkor az egyiket tetszolegesen kivalasztjuk gyokernek
			halmazok[u] = halmazok[v] = halmazok[u] + halmazok[v];		//a halmazuk hossza pedig a sajat halmazuk osszege lesz
		}
		else
		{
			if (Kotott(u) && !Kotott(v))				//ha csak az egyik kotott akkor ahhoz kotjuk a szabad csucsot es annak megfeleloen allitja a halmazok hosszat
			{
				szulo[v] = u;
				halmazok[u]++;
				halmazok[v] = halmazok[u];
			}
			else
			{
				if (Kotott(v) && !Kotott(u))
				{
					szulo[u] = v;
					halmazok[v]++;
					halmazok[u] = halmazok[v];
				}
				else
				{
					if (halmazok[u] > halmazok[v])					//ha mindketto kottot akkor a hosszabbikhoz kotjuk a rovidebb halmazt
					{
						szulo[v] = u;
						halmazok[u] += halmazok[v];
						halmazok[v] = halmazok[u];
					}
					else
					{
						szulo[u] = v;
						halmazok[v] += halmazok[u];
						halmazok[u] = halmazok[v];
					}
				}
			}
		}
	}
}

bool Graf::Kotott(int u)			//vizsgaljuk, hogy az adott csucs kotott-e 
{
	if (szulo[u] == -1)
		return 0;

	return 1;
}

int Graf::Keres(int u)						//fuggveny amelynek segitsegevel rekurzivan visszakeressuk az aktualis csucs gyokeret
{											//rekurziobol visszafele pedig a bejart csucsoknak megadjuk a megtalalt gyokeret mint szulot
	if (szulo[u] == -1)
		return u;
	else
	{
		int h = Keres(szulo[u]);
		if (h == u)
		{
			szulo[u] = -1;
		}
		else
		{
			szulo[u] = h;
		}
	}

}

bool Graf::Elerheto(int u, int v)					//fuggveny amellyel vizsgaljuk, hogy ket csucs kozott letezik-e egy ut
{
	int szulo_u = Keres(u);
	int szulo_v = Keres(v);
	if ((szulo_u == szulo_v) && (szulo_u != -1) && (szulo_v!= -1))		//megkeressuk mindkettonek a gyokeret , ha azok megegyeznek (es nem -1) akkor letezik ut a ket csucs kozott
		return 1;
	return 0;
}

bool Graf::Kozos(int u, int v)					//fuggveny amely megallitja, hogy ket csucs kozot komponenshez tartozik-e
{
	int gyoker_u = Keres(u);
	int gyoker_v = Keres(v);

	if (gyoker_u == gyoker_v)
		return 1;
	else
		return 0;
}