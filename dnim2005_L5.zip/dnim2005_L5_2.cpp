// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Azonosito: dnim2005
//
// Lab5 2. feladat
//
// Prim algoritmusa
// Hatarozzuk meg egy osszefuggo iranyitatlan graf minimalis feszitofajat O(m log n) idoben. 
// A Dijkstra algoritmusnal targyalt harom modszer kozul valasszunk egy masikat, mint amit a Dijkstra-nal hasznaltunk!
// (Az elozo Dijkstra algoritmusnal set-et hasznaltam, ezert most implementaltam a sajat min-heap adatszerkezetem.)

#include <iostream>
#include<fstream>
#include <vector>
#include <queue>

#define INF 99999999
#define NINF -99999999
#define ll long long

using namespace std;

string inout = "lab5_2_1.";

void csere_int(int& a, int& b);						//ket azonos tipusu tag felcserelese
void csere(pair<int, int>& a, pair<int, int>& b);

class minHeap {					//minimum kupac

public:

	minHeap(int max_kap) : max_kap(max_kap)		//konstruktor
	{ 
		heap.resize(max_kap);				//max_kap = maximalis tagok szama a kupacban
		index = new int[max_kap] {};		//index-el tartjuk szamon, hogy melyik csomopont milyen indexen van a kupacon belul
		for (int i = 0; i < max_kap; ++i)
		{
			index[i] = -1;					//eleinte mindenki egy nem letezo -1. indexen van elmeletben
		}
	}

	~minHeap() { heap.clear(); delete[] index; }		//destruktor ; felszabaditjuk a lefoglalt helyeket

	int szulo(int i);							//visszateriti az i. indexen levo tag szulojenek indexet
	int jobb_gyerek(int i);						//visszateriti az i. indexen levo tag jobb oldali gyerekenek indexet
	int bal_gyerek(int i);						//visszateriti az i. indexen levo tag bal oldali gyerekenek indexet
	void insert(int ind, int val);				//tag beillesztese a kupacba
	int min();									//visszateriti a kupac gyokeret (a legkisebb tagot) es kitorli azt a kupacbol
	void torol(int i);							//kitorli az i. indexen levo tagot
	void heapify(int i);						//az i. indextol kezdodoen vizsgalja es ha kell visszaallitja a kupacot, kupacra
	int ism(int ind);							// 1 -et terit vissza ha az ind = csucs meg "ismeretlen" 
	int empty();								// 1 -et terit vissza ha a kupac ures
	int is_in(int i);							// 1 - et terit vissza ha az i csucs benne van a kupacban

private:
	vector < pair <int, int> > heap;			// .first = a tavolsag | .second = a csucs
	int* index;
	int max_kap;
	int akt_meret = 0;
};

int minHeap::empty()
{
	if (akt_meret == 0)
		return 1;
	return 0;
}

int minHeap::szulo(int i)
{
	return (i-1)/2;
}

int minHeap::jobb_gyerek(int i)
{
	return 2 * (i + 1);
}

int minHeap::bal_gyerek(int i)
{
	return 2 * i + 1;
}

void minHeap::insert(int ind, int val) {

	if (akt_meret < max_kap)			//vizsgaljuk, hogy van-e meg hely
	{
		int i = akt_meret;
		akt_meret++;
		heap[i].first = val;
		heap[i].second = ind;
		index[ind] = i;					//ha igen akkor beillesztjuk a kupacot abrazolo tomb vegere az uj tagot

		while (i != 0 && heap[szulo(i)].first > heap[i].first)		//majd a helyere tesszuk az uj tagot
		{
			csere_int(index[heap[i].second], index[heap[szulo(i)].second]);
			csere(heap[szulo(i)], heap[i]);
			i = szulo(i);
		}
	}
}

void minHeap::heapify(int i)		// az i bal es jobb gyerekekbol kiindulvarekurzivan ellenorizzuk a kupac kupac tulajdonsagat 
{
	int jobb = jobb_gyerek(i);
	int bal = bal_gyerek(i);
	int min = i;

	if (bal < akt_meret && heap[bal].first < heap[i].first)
	{
		min = bal;
	}

	if (jobb < akt_meret && heap[jobb].first < heap[min].first)
	{
		min = jobb;
	}

	if (min != i)
	{
		csere_int(index[heap[i].second], index[heap[min].second]);		//es javitjuk azt ha szukseges
		csere(heap[i], heap[min]);
		heapify(min);
	}
}

int minHeap::min() 
{
	if (akt_meret == 0)
	{
		return INF;
	}

	if (akt_meret == 1) 
	{
		akt_meret--;
		index[heap[0].second] = -1;
		return heap[0].second;
	}

	int mini = heap[0].second;			//mini megkapja a kupac minimumjat

	akt_meret--;						//csokkentjuk a kupac meretet

	index[heap[0].second] = -1;			//kiszedjuk a mini-hez tartozo csucsot a kupacbol
	heap[0] = heap[akt_meret];			//a kupac utolso tagjat a kupacelejere tesszuk
	index[heap[0].second] = 0;			//a hozzatartozo csucsnak az indexet modositjuk

	heapify(0);							//majd visszaallitjuk a kupacot kupacca

	return mini;						//visszateritjuk a minimalis erteket amit kitorultunk a kupacbol

}

void minHeap::torol(int ind)
{
	int i = index[ind];
	heap[i].first = NINF;		//a torlendo elem erteket negativ INF-nek vesszuk
	while (i != 0 && heap[szulo(i)].first > heap[i].first)			//hogy az igy felcsusszon szabalyosan a kupac elejere mint minimalis ertek
	{
		csere_int(index[heap[i].second], index[heap[szulo(i)].second]);
		csere(heap[szulo(i)], heap[i]);
		i = szulo(i);
	}
	min();						//majd a min-t meghivva toroljuk azt (a visszateritesi ertek itt nem erdekel minket)
}

int minHeap::ism(int ind)
{
	if (heap[index[ind]].first == INF)
		return 1;
	return 0;
}

int minHeap::is_in(int i)
{
	if (index[i] != -1)
		return 1;
	return 0;
}

void Beolvas(vector < vector < pair <int, int> > >& graf, int& n, int& m);

ll Prim(int s, const vector < vector < pair <int, int> > >& graf, vector <pair <int, int> >& mst);

void Kiir(const vector <pair <int, int> >& mst, ll ossz);

int main()
{
	vector < vector <pair <int, int> > > graf;
	vector <pair <int, int> > mst;
	int n, m;

	Beolvas(graf, n, m);
	ll min_ossz = Prim(0, graf, mst);
	Kiir(mst, min_ossz);

	mst.clear();
	graf.clear();

	return 0;
}

void csere(pair<int, int>& a, pair<int, int>& b)
{
	pair<int,int> c;
	c = a;
	a = b;
	b = c;
}

void csere_int(int& a, int& b)
{
	int c;
	c = a;
	a = b;
	b = c;
}

void Beolvas(vector < vector < pair <int, int> > >& graf, int& n, int& m)		//fuggveny amellyel beolvassuk a grafot szovegallomanybol
{
	ifstream in(inout + "in");

	in >> n >> m;

	graf.resize(n);
	int u, v, e;

	for (int i = 0; i < m; ++i)
	{
		in >> u >> v >> e;
		u--;	v--;

		graf[u].push_back(make_pair(e, v));		//szomszedsagi listat epitunk fel; a szomszedokat a sullyal egyutt taroljuk, az kerul az elso helyre
		graf[v].push_back(make_pair(e, u));
	}

	in.close();
}

ll Prim(int s, const vector < vector < pair <int, int> > >& graf, vector <pair <int, int> >& mst)		// Prim algoritmusa
{
	ll* d = new ll[graf.size()];				//d - a csucsokhoz tartozo minimalis tavolsagok tombje
	int* p = new int[graf.size()];				//p - apasagi vektor
	minHeap ismeretlen(graf.size());			//ismeretleneket szamontarto minimalis kupac
	int u, v, w;
	ll ossz = 0;								//minimalis osszeg

	for (int i = 0; i < graf.size(); ++i)		//inicializaljuk a d es p tomboket
	{
		ismeretlen.insert(i, INF);
		d[i] = INF;
		p[i] = - 1;
	}
	d[s] = 0;			//beallitjuk a gyokerre vonatkozo informaciokat
	p[s] = 0;

	while (!ismeretlen.empty())		//megyunk ameddig az ismeretlen kupac ures nem lesz (ki nem szamolunk minden csucsnak egy tavolsagot)
	{
		u = ismeretlen.min();		//u megkapja a legkisebb tavolsaggal rendelkezo csucsot
		if (u != s)					//ha u nem a gyoker, akkor bekerul az szulojevel a minimalis feszitofaba
		{
			mst.push_back(make_pair(p[u], u));
		}
		for (int i = 0; i < graf[u].size(); ++i)		//bejarjuk az u szomszedait
		{
			w = graf[u][i].first;
			v = graf[u][i].second;

			if (d[v] > w && ismeretlen.is_in(v))	//ha az u es v kozotti tavolsag kisebb mint a v-re mar kiszamolt tavolsag es v resze a kupacnak
			{
 				d[v] = w;							//d[v] megkapja az uj, kisebb tavolsagot
				p[v] = u;							//valamint v uj szuloje az u lesz
 				ismeretlen.torol(v);				//frissitjuk a kupacot
				ismeretlen.insert(v, d[v]);
			}
		}
	}

	for (int i = 0; i < graf.size(); ++i)			//a d tombot bejarva kiszamoljuk a minimalis koltseget/tavolsagot
	{
		ossz += d[i];
	}

	delete[] d;
	delete[] p;

	return ossz;
}

void Kiir(const vector <pair <int, int> >& mst, ll ossz)		//fuggveny amellyel kiirjuk a minimalis feszitofa koltseget es a benne levo eleket
{
	ofstream out(inout + "out");

	out << ossz << endl;

	for (int i = 0; i < mst.size(); ++i)
	{
		out << mst[i].first + 1 << " " << mst[i].second + 1 << endl;
	}

	out.close();
}