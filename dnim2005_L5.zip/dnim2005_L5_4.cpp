// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Azonosito: dnim2005
//
// Lab5 4. feladat
//
// Online MST (Minimalis feszitofa inkrementalis feladata dinamikus grafokban)
// Adott egy n csucsu m elu osszefuggo iranyitatlan graf, amihez utolag hozzaadunk meg k elet. 
// Hatarozzuk meg az eredeti graf minimalis feszitofajat, majd minden uj el hozzaadsa utan az uj minimalis feszitofat. 
// Hasznaljunk O(n) idot lekerdezesenkent!

#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

#define MAX_SULY 251

using namespace std;

string inout = "lab5_4_1.";

void Beolvas(int& n, int& m, int& k, vector <pair <int, pair<int, int> > >& elek, vector <pair <int, pair<int, int> > >& k_el);

void Rendez(int m, vector <pair <int, pair <int, int>>>& elek);

void Init_Szulo(vector <int>& szulo);

int Keres_Rep(int x, vector <int>& szulo);

void Egyesit(int u, int v, vector <int>& szulo, vector <int>& rank);

int Kruskal(vector < vector < pair <int, int> > >& mts, vector < pair <int, pair <int, int> > >& elek, vector <int>& szulo, vector <int>& rank);

pair <int, pair<int, int> > Keres(const vector <vector <pair <int, int> > >& mst, pair < int, pair <int, int> > uj_el);

void Torol(vector < vector <pair <int, int> > >& mst, const pair< int, pair<int, int> > max);

void Online_MST(vector <pair <int, pair<int, int> > >& elek, vector <vector <pair <int, int> > >& mst, vector <pair <int, pair <int, int> > > k_el);

int main()
{
	vector < pair <int, pair<int, int> > > elek;
	vector <pair <int, pair <int, int> > > k_el;
	vector < vector < pair <int, int> > > mst;

	int n, m, k, ossz = 0;

	Beolvas(n, m, k, elek, k_el);
	mst.resize(n);
	
	Online_MST(elek, mst, k_el);

	mst.clear();
	k_el.clear();
	elek.clear();

	return 0;
}

void Beolvas(int& n, int& m, int& k, vector <pair <int, pair<int, int> > >& elek, vector <pair <int, pair<int, int> > >& k_el)
{
	ifstream in(inout + "in");

	in >> n >> m;
	elek.resize(m);

	int s, u, v;

	for (int i = 0; i < m; ++i)					//beolvassuk az graf eleit egy ellistaba
	{
		in >> u >> v >> s;
		u--;	v--;

		elek[i] = make_pair(s, make_pair(u, v));
	}

	in >> k;
	for (int i = 0; i < k; ++i)				//majd beolvassuk egy k_elek tombbe a majd bejovo eleket
	{
		in >> u >> v >> s;
		u--;	v--;

		k_el.push_back(make_pair(s, make_pair(u, v)));			// suly, csucs1, csucs2
	}

	in.close();
}

void Rendez(int m, vector <pair <int, pair <int, int>>>& elek)		//fuggveny amely count sorttal novekvo sorrendbe rendezi az elek listajat
{
	int* darab = new int[MAX_SULY] {0};
	vector <pair <int, pair <int, int>>> seged;
	seged.resize(m + 1);

	for (int i = 0; i < m; ++i)
	{
		darab[elek[i].first]++;
	}

	for (int i = 1; i < MAX_SULY; ++i)
	{
		darab[i] += darab[i - 1];
	}

	for (int i = m - 1; i >= 0; --i)
	{
		seged[darab[elek[i].first]] = elek[i];
		darab[elek[i].first]--;
	}

	for (int i = 1; i <= m; ++i)
	{
		elek[i - 1] = seged[i];
	}

	seged.clear();
	delete[] darab;
}

void Init_Szulo(vector <int>& szulo)			//inicializaljuk a szulo vektort
{
	for (int i = 0; i < szulo.size(); ++i)
	{
		szulo[i] = i;							//eleinte mindenki onmaga szuleje
	}
}

int Keres_Rep(int x, vector <int>& szulo)		//a szulo vektor altal visszakeressuk annak a halmaznak a kepviselojet amiben az x szerepel
{
	if (szulo[x] != x)
	{
		szulo[x] = Keres_Rep(szulo[x], szulo);
	}

	return szulo[x];
}

void Egyesit(int u, int v, vector <int>& szulo, vector <int>& rank)		//fuggveny amely egyesit ket diszjunkt halmazt
{
	int u_rep = Keres_Rep(u, szulo);		//megkeressuk mindket tagnak a kepviselojet
	int v_rep = Keres_Rep(v, szulo);

	if (u_rep != v_rep)						//vizsgaljuk, hogy egy halmazban lennenek-e
	{
		if (rank[u_rep] < rank[v_rep])		//ha nem, akkor nezzuk, hogy melyik rendelkezik a nagyobb ranggal
		{
			szulo[u_rep] = v_rep;			//a kisebb rangu kepviselo megkapja a masik kepviselot mint szulot
		}
		else
		{
			if (rank[u_rep] > rank[v_rep])
			{
				szulo[v_rep] = u_rep;
			}
			else
			{
				szulo[v_rep] = u_rep;			//ha azonos ranguak akkor az egyik kepviselo megkapja a masikat mint szulo
				rank[u_rep] = rank[v_rep] + 1;	//es az uj kepviselo rankjat noveljuk eggyel
			}
		}
	}
}

int Kruskal(vector < vector < pair <int, int> > >& mst, vector < pair <int, pair <int, int> > >& elek, vector <int>& szulo, vector <int>& rank)
{
	Rendez(elek.size(), elek);								//rendezzuk az eleket csokkeno sorrendbe

	int u, v, w, ossz = 0;
	for (int i = 0; i < elek.size(); ++i)					//bejarjuk az eleket tartalmazo vektort
	{
		u = elek[i].second.first;
		v = elek[i].second.second;
		w = elek[i].first;
		if (Keres_Rep(u, szulo) != Keres_Rep(v, szulo))		//ha egy el ket vegpont nem egy halmazhoz tartoznak
		{
			mst[u].push_back(make_pair(v,w));			//az mst-t egy szomszedsagi listakent irjuk fel
			mst[v].push_back(make_pair(u, w));			//csucs1, csucs2, suly
			ossz += w;									//kiszamoljuk a minimalis koltseget
			Egyesit(u, v, szulo, rank);					//egyesitjuk a ket csucsot
		}
	}

	return ossz;										//visszateritjuk az osszeget
}

//fuggveny amely megeresi ket csucs kozotti utban a legnagyobb sullyal rendelkezo elt | melysegi bejarast alkalmazunk ehhez
pair <int, pair<int, int> > Keres (const vector <vector <pair <int, int> > >& mst, pair < int, pair <int, int> > uj_el)	
{
	bool* volt = new bool[mst.size()]{false};
	stack <pair <int, pair <int, int> > > s;
	int p = uj_el.second.first;
	int akt_p = p;
	s.push(uj_el);
	int bejart = 0;
	volt[p] = true;
	pair <int, pair<int, int>> max = make_pair(-1, make_pair(0, 0));
	pair <int, pair<int, int> > seged;
	int u, w;

	while (p != uj_el.second.second && !s.empty())		//addig megyunk ameddig nem ertuk el az uj el masik csucsat
	{
		akt_p = p;
		for (int i = 0; i < mst[p].size(); ++i)		//bejarjuk a p szomszedait
		{
			u = mst[p][i].first;
			w = mst[p][i].second;
			if (volt[u] == false)					//nezzuk, hogy voltunk-e mar az u csucsban
			{
				volt[u] = true;
				s.push(make_pair(w, make_pair(u, p)));
				p = u;
			}
		}

		if (akt_p == p)
		{
			p = s.top().second.second;
			s.pop();
		}
	}

	while (!s.empty())
	{
		seged = s.top();
		s.pop();
		if (seged != uj_el && seged.first > max.first)
		{
			max = seged;
		}
	}

	delete[] volt;

	return max;			//visszateritjuk a maximalis elet
}

//fuggveny amellyel kitoroljuk az mst-bol a felesleges elet
void Torol(vector < vector <pair <int, int> > >& mst, const pair< int, pair<int, int> > max)	//max : suly, csucs, csucs || mst : csucs, csucs, suly
{
	int i = 0;
	int u;

	u = mst[max.second.first][0].first;
	while (i < mst[max.second.first].size() &&  u != max.second.second)		//megkeressuk az elet az elso csucs szomszedsagi vectoraban
	{
		i++;
		u = mst[max.second.first][i].first;
	}
	
	if (mst[max.second.first].size() >= 1)
	{
		i++;
		while (i < mst[max.second.first].size())
		{
			mst[max.second.first][i - 1] = mst[max.second.first][i];
			i++;
		}
	mst[max.second.first].resize(mst[max.second.first].size() - 1);
	}


	i = 0;
	u = mst[max.second.second][0].first;
	while (i < mst[max.second.second].size() && u != max.second.first)	//megkeressuk az elet a masodik csucs szomszedsagi vectoraban
	{
		i++;
		u = mst[max.second.second][i].first;
	}

	if (mst[max.second.second].size() >= 1)
	{
		i++;
		while (i < mst[max.second.second].size())
		{
			mst[max.second.second][i - 1] = mst[max.second.second][i];
			i++;
		}

	mst[max.second.second].resize(mst[max.second.second].size() - 1);
	}

}

void Online_MST(vector <pair <int, pair<int, int> > >& elek, vector <vector <pair <int, int> > >& mst, vector <pair <int, pair <int, int> > > k_el)
{
	ofstream out(inout + "out");

	vector <int> szulo;
	vector <int> rank;
	int ossz = 0;

	szulo.resize(mst.size());
	rank.resize(mst.size());

	Init_Szulo(szulo);

	ossz = Kruskal(mst, elek, szulo, rank);		//Kruskallal meghatarozzuk az alap graf minimalis feszitofajat

	out << ossz << endl;						//beiratjuk a kimeneti szovegallomanyba a minimalis koltseget

	int u, v, w;
	pair <int, pair <int, int> > max;
	for (int i = 0; i < k_el.size(); ++i)		//bejarjuk a bejovo elek vektorat
	{
		max = Keres(mst, k_el[i]);				//megkeressuk, hogy a bejovo el ket csucsa kozott melyik az a csucs amelyk a legnagyobb sullyal rendelkezik

		if (max.first > k_el[i].first)			//ha ez a maximalis suly nagyobb mint a beerkezo el sulya akkor
		{
			u = k_el[i].second.first;
			v = k_el[i].second.second;
			w = k_el[i].first;
			Torol(mst, max);					//kitoroljuk a maximalis elet
			ossz -= max.first;					//kivonjuk a torolt el sulyat az osszegbol
			ossz += w;							//hozzaadjuk az uj sulyt

			mst[u].push_back(make_pair(v, w));	//es betesszuk az uj elet az mst-be
			mst[v].push_back(make_pair(u, w));
		}

		out << ossz << endl;					//majd kiiratjuk a kimeneti allomanyba az aktualis minimalis koltseget
	}

	rank.clear();
	szulo.clear();

	out.close();
}