// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Azonosito: dnim2005
//
// Lab5 3. feladat
//
// Kruskal algoritmusa
// Hatarozzuk meg egy osszefuggo iranyitatlan graf minimalis feszitofajat O(m alpha(n)) idoben. 
// Rendezzuk az eleket linearisan es hasznaljuk a diszjunkt halmaz adatstrukturat!

#include <iostream>
#include <fstream>
#include <vector>

#define MAX_SULY 10001

using namespace std;

string inout = "lab5_3_1.";

void Beolvas(int& n, int& m, vector <pair <int, pair<int, int> > >& elek);

void Rendez(int m, vector <pair <int, pair <int, int>>>& elek);

void Init_Szulo(vector <int>& szulo);

int Keres_Rep(int x, vector <int>& szulo);

void Egyesit(int u, int v, vector <int>& szulo, vector <int>& rank);

int Kruskal(vector <pair <int, int> >& mts, vector < pair <int, pair <int, int> > >& elek, vector <int>& szulo, vector <int>& rank);

void Kiir(int ossz, const vector <pair <int, int> >& mts);

int main()
{

	vector < pair <int, pair <int, int> > > elek;
	vector < pair <int, int> > mts;
	vector <int> szulo;
	vector <int> rank;
	int n, m, ossz;

	Beolvas(n, m, elek);

	szulo.resize(n);
	rank.resize(n);

	Init_Szulo(szulo);

	ossz = Kruskal(mts, elek, szulo, rank);

	Kiir(ossz, mts);

	elek.clear();
	szulo.clear();
	rank.clear();
	mts.clear();

	return 0;
}

void Beolvas(int& n, int& m, vector <pair <int, pair<int, int> > >& elek)		//beolvassuk a graf eleit es felepitjuk az ellistajat
{
	ifstream in(inout + "in");

	in >> n >> m;
	elek.resize(m);
	
	int s, u, v;

	for (int i = 0; i < m; ++i)
	{
		in >> u >> v >> s;
		u--;	v--;
		
		elek[i] = make_pair(s, make_pair(u, v));
	}

	in.close();
}

void Rendez(int m, vector <pair <int, pair <int, int>>>& elek)		//count sort az elek rendezesere
{
	int* darab = new int[MAX_SULY] {0};
	vector <pair <int, pair <int, int>>> seged;
	seged.resize(m + 1);

	for (int i = 0; i < m; ++i)
	{
		darab[elek[i].first]++;
	}

	for (int i = 1; i < MAX_SULY; ++i)
	{
		darab[i] += darab[i - 1];
	}

	for (int i = m - 1; i >= 0; --i)
	{
		seged[darab[elek[i].first]] = elek[i];
		darab[elek[i].first]--;
	}

	for (int i = 1; i <= m; ++i)
	{
		elek[i - 1] = seged[i];
	}

	seged.clear();
	delete[] darab;
}

void Init_Szulo(vector <int>& szulo)			//a szulo vectort inicializalo fuggveny
{
	for (int i = 0; i < szulo.size(); ++i)
	{
		szulo[i] = i;							//eleinte mindenki onmaga szuloje
	}
}

int Keres_Rep(int x, vector <int>& szulo)		//a szulo vektor altal visszakeressuk annak a halmaznak a kepviselojet amiben az x szerepel
{
	if (szulo[x] != x)
	{
		szulo[x] = Keres_Rep(szulo[x], szulo);
	}

	return szulo[x];
}

void Egyesit(int u, int v, vector <int>& szulo, vector <int>& rank)		//fuggveny amely egyesit ket diszjunkt halmazt
{
	int u_rep = Keres_Rep(u, szulo);		//megkeressuk mindket tagnak a kepviselojet
	int v_rep = Keres_Rep(v, szulo);

	if (u_rep != v_rep)						//vizsgaljuk, hogy egy halmazban lennenek-e
	{
		if (rank[u_rep] < rank[v_rep])		//ha nem, akkor nezzuk, hogy melyik rendelkezik a nagyobb ranggal
		{
			szulo[u_rep] = v_rep;			//a kisebb rangu kepviselo megkapja a masik kepviselot mint szulot
		}
		else
		{
			if (rank[u_rep] > rank[v_rep])
			{
				szulo[v_rep] = u_rep;
			}
			else
			{
				szulo[v_rep] = u_rep;			//ha azonos ranguak akkor az egyik kepviselo megkapja a masikat mint szulo
				rank[u_rep] = rank[v_rep] + 1;	//es az uj kepviselo rankjat noveljuk eggyel
			}
		}
	}
}

int Kruskal(vector <pair <int, int> >& mts, vector < pair <int, pair <int, int> > >& elek, vector <int>& szulo, vector <int>& rank)
{
	Rendez(elek.size(), elek);								//rendezzuk az eleket csokkeno sorrendbe
	int u, v, ossz = 0;

	for (int i = 0; i < elek.size(); ++i)					//bejarjuk az eleket tartalmazo vektort
	{
		u = elek[i].second.first;
		v = elek[i].second.second;
		if (Keres_Rep(u, szulo) != Keres_Rep(v,szulo))		//ha egy el ket vegpont nem egy halmazhoz tartoznak
		{
			mts.push_back(make_pair(u, v));					//akkor az el bekerul minimalis feszitofaba
			ossz += elek[i].first;							//ossz-hoz hozzadjuk az el sulyat
			Egyesit(u, v, szulo, rank);						//es egyesitjuk a ket halmazt
		}
	}

	return ossz;											//visszateritjuk a minimalis koltseget
}

void Kiir(int ossz, const vector <pair <int, int> >& mts)		//fuggveny amely kiiratja a minimalis feszitofa koltseget es a benne levo eleket
{
	ofstream out(inout + "out");

	out << ossz << endl;

	for (int i = 0; i < mts.size(); ++i)
	{
		out << mts[i].first + 1 << " " << mts[i].second + 1 << endl;
	}

	out.close();
}