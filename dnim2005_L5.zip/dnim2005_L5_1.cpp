// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Azonosito: dnim2005
//
// Lab5 1. feladat
//
// LCA
// Adott egy gyokeres fa, melynek a gyokere mindig az 1-es csucs es k darab csucspar.
// Hatarozzuk meg a legkisebb kozos osuket az eloadasban bemutatott harom algoritmus (LCA_SQRT, LCA_LOG, LCA_TARJAN) valamelyiket hasznalva!

#include <iostream>
#include <fstream>
#include <vector>
#include <utility>

using namespace std;

string inout = "lab5_1_1.";

void Beolvas(int& n, vector <vector <int>>& fa, vector <int>& szulo, vector <pair <int, int>>& utasitas);

void Szintek(int a, const vector <vector<int>>& fa, vector <int>& szint, int& h);

int log_2(int a);

void p_tomb(int h, const vector <int>& szint, const vector <int>& szulo, int** p);

void csere(int& a, int& b);

int LCA_LOG(int u, int v, const vector<int>& szint, int** p, const vector<int>& szulo);

void Kiir(const vector <pair <int, int> >& utasitas, const vector <int>& szint, const vector <int>& szulo, int** p);

int main()
{

	vector <vector <int>> fa;
	vector <int> szulo, szint;
	vector < pair <int, int> >utasitas;
	int n, h = -1, l;
	int** p;

	Beolvas(n, fa, szulo, utasitas);
	szint.resize(n);

	szint[0] = 1;					//kinevezzuk az 1-es csomopontot gyokernek ; o lesz az elso szinten
	Szintek(0, fa, szint, h);		//kiszamoljuk minden csucsnak a szintjet
	l = log_2(h);
	p = new int* [n];

	for (int i = 0; i < n; ++i)
		p[i] = new int[l + 1];

	p_tomb(h, szint, szulo, p);		//inicializaljuk a p (szuperszulok) tombjet

	Kiir(utasitas, szint, szulo, p);

	for (int i = n - 1; i >= 0; --i)		//felszabaditjuk a lefoglalt helyeket
	{
		delete[] p[i];
	}
	delete[] p;

	utasitas.clear();
	szint.clear();
	szulo.clear();
	fa.clear();

	return 0;
}

void Beolvas(int& n, vector <vector <int>>& fa, vector <int>& szulo, vector <pair <int, int>>& utasitas)		//beolvassuk a fat es az utasitasokat
{
	ifstream in(inout + "in");
	int k;
	in >> n >> k;
	fa.resize(n);
	szulo.resize(n);
	szulo[0] = -1;		//a gyoker szulejet -1 -nek valasszuk meg

	int u, v;

	for (int i = 1; i < n; ++i)
	{
		in >> v;
		v--;

		fa[v].push_back(i);		//felepitjuk a fat
		szulo[i] = v;			//beolvassuk az apasagi tombot
	}

	for (int i = 0; i < k; ++i)		//beolvassuk az utasitasokat is
	{
		in >> u >> v;
		u--;	v--;

		utasitas.push_back(make_pair(u, v));
	}

	in.close();
}

void Szintek(int a, const vector <vector<int>>& fa, vector <int>& szint, int& h)	//kiszamoljuk minden csucsra a szintjet
{
	for (int i = 0; i < fa[a].size(); ++i)
	{
		szint[fa[a][i]] = szint[a] + 1;
		
		h = szint[fa[a][i]] > h ? szint[fa[a][i]] : h;			//h-ban szamoljuk ki a fa magassagat

		Szintek(fa[a][i], fa, szint, h);
	}
}

int log_2(int a)	//fuggveny amely visszateriti egy szam kettes alapu logaritmusat
{
	int i = 0;
	while(a!=1)
	{
		a = a >> 1;
		i++;
	}

	return i;
}

void p_tomb(int h, const vector <int>& szint, const vector <int>& szulo, int** p)	//fuggveny amellyel felepitjuk a fa p matrixat ; ahol p[u][i] az u azon ose amely 2^i szinttel feljebb van
{
	int l = log_2(h);						//l megkapja a fa magassaganak kettes alapu logaritmusat

	for (int i = 1; i < szint.size(); ++i)		//mindegyik csucs 0. szuperszuloje a direkt szuloje
		p[i][0] = szulo[i];

	for (int i = 1; i <= l; ++i)			//mivel csak log_2(h) -ig mehet felfele ezert, csak l-ig megy a cklis
	{
		for (int u = 1; u < szint.size(); ++u)
		{

			if (szint[u] <= (1 << i))		//ha az u tul magasan van akkor az 2^i siznttel feljebbi oset -1 -nek vesszuk
				p[u][i] = -1;
			else
			{
				p[u][i] = p[p[u][i - 1]][i - 1];	//kulonben megkapja a megfelelo csucsot mint os
			}
		}
	}
}


void csere(int& a, int& b)		//ket int tipusu tagot felcserelo fuggveny
{
	int c = a;
	a = b;
	b = c;
}

int LCA_LOG(int u, int v, const vector<int>& szint, int** p, const vector<int>& szulo)		//LCA algoritmus amely logaritmikus idoben megallapitja ket csucs legkisebb kozos oset
{
	if (szint[u] < szint[v])		//ha u fentebb van mint a v, akkor felcsereljuk oket
		csere(u, v);

	int lg = log_2(szint[u]);
	
	for (int i = lg; i >= 0; --i)				//azonos szintre hozzuk az u-t a v-vel
	{
 		if ((szint[u] - (1 << i)) >= szint[v])
			u = p[u][i];						//ha meg a v allatt vagy v-re kerulnenk az 2^i hatvannyal, akkor az u megkapja az i-dik szuperszulojet
	}

	if (u == v)								//ha u es v azonosak akkor megtalaltuk a legkisebb kozos ost (ami a v)
		return u;

	for (int i = lg; i >= 0; --i)			//elkezdunk felfele menni mindket csucsbol
	{
		if ((p[u][i] != -1) && (p[u][i] != p[v][i]))	//ameddig nem lesz az u i. szuperszuloje nem -1 es u es v szuperszuloje nem egyenlo addig ugralunk feljebb
		{
			u = p[u][i];
			v = p[v][i];
		}
	}									
										
	return szulo[u];	//amikor u es v i. szuperszuloje egyenlo lenne akkor visszaterithetjuk az u vagy v kozvetlen szulejet
}

void Kiir(const vector <pair <int, int> >& utasitas, const vector <int>& szint, const vector <int>& szulo, int** p)
{
	ofstream out(inout + "out");
	int help;
	for (int i = 0; i < utasitas.size(); ++i)			//vegigmegyunk az utasitasokon/lekerdezeseken
	{
		out << LCA_LOG(utasitas[i].first, utasitas[i].second, szint, p, szulo) + 1 << endl;	//es kiiratjuk a csucsok legkisebb kozos oset egy szovegallomanyba
	}

	out.close();
}