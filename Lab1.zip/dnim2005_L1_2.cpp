// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Lab1 2.feladat
//
// Adott egy osszefuggo iranyitatlan multigraf, hatarozzuk meg az 1-es csucsbol indulva a melysegi es a szelessegi bejaras sorrendjet. 
// Vegyuk eszre, hogy a melysegi bejaras rekurzivan implementalva erosen terheli a verem memoriat, ezert implementaljuk iterativan is! 
// Hasznalhatunk tombot, vagy a programozasi nyelv altal nyujtott dinamikus adatstrukturat (pl. STL-ben "stack") a verem szimulalasahoz.

#include <iostream>
#include <vector>
#include <stack>
#include <queue>
#include <fstream>

#define MAX_CSUCS 1000001

using namespace std;

string inout = "lab1_2_5.";

void Beolvas(vector <vector <int> >& g, int& n, int& m);

void Reset(vector <int>& sorrend, int n, bool* volt);

void Volt_Reset(int n, bool* volt);

void Rek_Melysegi(const vector < vector < int > >& g, int p, vector <int>& sorrend, bool* volt);

void Ite_Melysegi(const vector <vector < int > >& g, vector <int>& sorrend, bool* volt);

void Szelessegi(const vector <vector < int > >& g, vector <int>& sorrend, bool* volt);

void Bejarasok(const vector <vector <int> >& g, int n);

void Kiir_Bejaras(const vector <int>& sorrend, ofstream& out);

int main()
{
	vector <vector  < int > > graf;
	int n, m;
	Beolvas(graf, n, m);

	Bejarasok(graf, n);

	graf.clear();

	return 0;
}

void Beolvas(vector <vector <int> >& g, int& n, int& m)		//beolvassuk a graf ellistajat -> felepitjuk a szomszedsagi listat
{
	ifstream in(inout + "in");
	in >> n >> m;

	g.resize(n);

	int u, v;
	for (int i = 0; i < m; ++i)
	{
		in >> u >> v;
		u--;
		v--;

		g[u].push_back(v);
	//	g[v].push_back(u);

	}

	in.close();
}

void Reset(vector <int>& sorrend, int n, bool* volt)	//fuggveny amivel a seged tomboket es vektorokat beallitjuk a bejarasok kozott
{
	sorrend.clear();
	Volt_Reset(n, volt);

}

void Volt_Reset(int n, bool* volt)				//a volt tombot visszaallitja az alapertelmezett modjaba
{
	for (int i = 0; i < n; ++i)
		volt[i] = false;
}

void Rek_Melysegi(const vector < vector < int > >& g, int p, vector <int>& sorrend, bool* volt)		//a graf melysegi bejarasa rekurzivan megvalositva
{
	volt[p] = true;											//megjegyezzuk, hogy az aktualis csomopontot felhasznaltuk
	sorrend.push_back(p);									//betesszuk a sorrend tombbe az aktualis csomopontot
	for(int i = 0; i < g[p].size(); ++i)					//bejarjuk az aktualis csomopont szomszedait
		if (volt[g[p][i]] == false)
		{
			Rek_Melysegi(g, g[p][i], sorrend, volt);		//meghivjuk rekurzivan a fuggvenyt azokra a szomszedokra amelyeken meg nem jartunk
		}
}

void Ite_Melysegi(const vector <vector < int > >& g, vector <int>& sorrend, bool* volt)			//a graf melysegi bejarasa iterativan megvalositva
{
	stack <int> s;											//a 0. (1.) csucsbol inditjuk az osszefuggo graf bejarasat ezert arra a csucsra vonatkozo informaciokat frissitjuk
	s.push(0);
	int p = 0;
	int akt_p = 0;
	int bejart = 1;											//bejart - valtozo, amivel nyilvantartjuk, hogy hany csucsot latogattunk meg
	volt[0] = true;
	sorrend.push_back(0);									//betesszuk a sorrend-be mint kiindulasi pont

	while (bejart != g.size())								//ciklus amely addig megy amig nem voltunk minden csucsnal
	{
		akt_p = p;
		for (int i = 0; i < g[p].size() && akt_p == p; ++i)		//ciklus amely vagy az aktualis csucs szomszed listajanak a vegeig megy, vagy amig nem talaltunk egy meg meg nem latogatott szomszedot
		{
			if (volt[g[p][i]] == false)
			{
				volt[g[p][i]] = true;						//ha a szomszedja szabad akkor megjegyezzuk, hogy jartunk itt
				sorrend.push_back(g[p][i]);					//betesszuk a sorrendbe
				bejart++;									//noveljuk a bejart csucsok szamat
				s.push(p);									//verembe tesszuk a meg minding aktualisnak szamito csucsot
				p = g[p][i];								//az uj aktualis csucs a (mar meglatogatott) szomszed lesz

			}
		}

		if (akt_p == p)										//ha nem kaptunk p-nek szabad szomszedot, akkor a verem tetejerol kiszedjuk az elozo csucsokat
		{
			p = s.top();
			s.pop();
		}
	}

}

void Szelessegi(const vector <vector < int > >& g, vector <int>& sorrend, bool* volt)		//graf szelessegi bejarasat megvalosito fuggveny
{
	queue <int> q;
	volt[0] = true;										//beallitjuk a kiinduloponthoz tartozo informaciokat
	sorrend.push_back(0);
	q.push(0);											//betesszuk a queue-ba a csucsot
	int u;
	while (!q.empty())									//ciklus, amely addig megy amig a queue ki nem urult
	{
		u = q.front();									//u megkapja a queue-bol a FIFO szerkezet szerinti elso elemet
		for (int i = 0; i < g[u].size(); ++i)			//bejarja ennek a szomszedait
		{
			if (volt[g[u][i]]== false)
			{
				volt[g[u][i]] = true;			
				sorrend.push_back(g[u][i]);				//a szabad szomszedokat beteszi a sorrendbe es a queue-ba is lementi
				q.push(g[u][i]);
			}
		}
		q.pop();										//ezt kovetoen kiszedi a bejart csucsot a queue-bol
	}
}

void Bejarasok(const vector <vector <int> >& g, int n)		//fuggveny amely meghivja a bejarasi fuggvenyeket
{
	ofstream out(inout + "out");

	bool* volt = new bool [n] {false};

	vector <int> sorrend;
	sorrend.reserve(n);

	Rek_Melysegi(g, 0, sorrend, volt);
	out << "Melysegi bejaras rekurzivan: ";
	Kiir_Bejaras(sorrend, out);

	Reset(sorrend, n, volt);								//bejarasok kozott ujra beallitjuk a seged tomboket/vektorokat

	Ite_Melysegi(g, sorrend, volt);
	out << "Melysegi bejaras iterativan: ";
	Kiir_Bejaras(sorrend, out);

	Reset(sorrend, n, volt);

	Szelessegi(g, sorrend, volt);
	out << "Szelessegi bejaras: ";
	Kiir_Bejaras(sorrend, out);

	sorrend.clear();
	delete[] volt;
	out.close();
}

void Kiir_Bejaras(const vector <int>& sorrend, ofstream& out)		//fuggveny amely allomanyba kiirja a sorrend vector tartalmat
{
	for (int i = 0; i < sorrend.size(); ++i)
		out << sorrend[i] + 1 << " ";
	out << endl;
}



