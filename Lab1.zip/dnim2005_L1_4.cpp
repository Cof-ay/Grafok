//Nev: Domokos Nikolette - Beatrice
//Csoport: 511/2
//Lab1 4.feladat
//
// Allapitsuk meg egy egyszeru iranyitott graf erosen osszefuggo komponenseit! Hasznaljunk minel hatekonyabb algoritmust (termeszetesen)!

#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

#define MAX_CSUCS 1000001

using namespace std;

string inout = "leti.";

void Beolvas(vector <vector <int> >& g, int& n, int& m);

void Init_Belep(int* belep, int n);

void Tarjan_SC(const vector <vector <int> >& g, int m, int v, int& ido, int* belep, int* low, stack <int>& s, bool* vermen, int& komp_db, vector <vector <int> >& komp, bool* volt);


void Kiiras(const vector <vector <int> >& komp, int komp_db);

int main()
{
	vector <vector <int> > graf;
	int n, m;
	Beolvas(graf, n, m);

	int* belep = new int[n];
	Init_Belep(belep, n);

	int* low = new int[n];
	bool* vermen = new bool[n] {false};
	bool* volt = new bool[n] {false};
	int komp_db = 0, ido = -1;
	
	stack <int> s;
	vector <vector <int> > komp;

	for (int i = 0; i < n; ++i)
	{
		if (volt[i] == false)
		{
			Tarjan_SC(graf, m, i, ido, belep, low, s, vermen, komp_db, komp, volt);
		}
	}
	Kiiras(komp, komp_db);

	graf.clear();
	komp.clear();

	delete[] volt;
	delete[] belep;
	delete[] low;
	delete[] vermen;

	return 0;
}

void Beolvas(vector <vector <int> >& g, int& n, int& m)		//beolvassuk a graf ellistajat -> felepitjuk a szomszedsagi listat
{
	ifstream in(inout + "in");
	in >> n >> m;

	g.resize(n);

	int u, v;
	for (int i = 0; i < m; ++i)
	{
		in >> u >> v;
		u--;
		v--;

		g[u].push_back(v);

	}

	in.close();
}

void Init_Belep(int* belep, int n)
{
	for (int i = 0; i < n; ++i)
		belep[i] = -1;
}

void Tarjan_SC(const vector <vector <int> >& g,int m, int v, int& ido, int* belep, int* low, stack <int>& s, bool* vermen, int& komp_db, vector <vector <int> >& komp, bool* volt)		//Tarjan StrongCoonnect algoritmusa
{
	ido++;									//noveljuk az idot
	belep[v] = ido;							//majd lementjuk, hogy melyik idopillantaban latogatjuk meg az aktualis csucsot
	low[v] = ido;							
	vermen[v] = true;						//megjegyezzuk,hogy ezt a csucsot betettuk a verembe
	s.push(v);
	volt[v] = true;

	for (int i = 0; i < g[v].size(); ++i)			//bejarjuk az aktualis csucs szomszedait
	{
		if (belep[g[v][i]] == -1)					//keresunk egy olyat amin meg nem voltunk
		{
			Tarjan_SC(g,m, g[v][i], ido, belep, low, s, vermen, komp_db, komp, volt);			//es azt meglatogatjuk
			low[v] = low[v] < low[g[v][i]] ? low[v] : low[g[v][i]];						//majd az aktualis csucs-ot a minimalis low ertek fogja jellemezni
		}
		else
		{
			if ((belep[g[v][i]] < belep[v]) && vermen[g[v][i]])							//ha nincs nem meglatogatott szomszed es a szomszed belepesi erteke kisebb mint az aktualis csucse es mar a veremben van
			{
				low[v] = low[v] < low[g[v][i]] ? low[v] : low[g[v][i]];					//akkor az aktualis csucs low-ja a ketto kozul a kisebb low-t kapja meg
			}
		}
	}

	if (low[v] == belep[v])									//ha a low es a belepes megegyezik ES letezik legalabb ket el
	{
		komp_db++;														//akkor noveljuk az erosen osszefuggo komponensek szamat
		while (!s.empty() && (belep[s.top()] >= belep[v]))				//egy ciklussal addig megyunk amig a verem ki nem urult vagy emddgi a verem tetejen levo csucsnak a belepese kisebb nem lesz mint az aktualis csucse
		{
			if (komp.size() < komp_db)
			{
				komp.resize(komp_db);									//ha szukszeges akkor noveljuk a komponensek listajat
			}

			komp[komp_db - 1].insert(komp[komp_db-1].begin(), s.top());		//betesszuk a (komp_db-1). lista elejere a verem tetejen levo tagot
			vermen[s.top()] = false;										//mivel kiszedjuk a verem tetejerol a tagot, ezert a vermen tombot is allitjuk
			s.pop();														
		}
	}

}

void Kiiras(const vector <vector <int> >& komp, int komp_db)			//fuggveny amivel kiiratjuk a komponensek darabszamat es listajat egy allomanyba
{
	ofstream out(inout + "out");

	out << komp_db << endl;
	for (int i = 0; i < komp.size(); ++i)
	{
		for (int j = 0; j < komp[i].size(); ++j)
			out << komp[i][j] + 1 << " ";
		out << endl;
	}

	out.close();
}