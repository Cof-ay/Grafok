//Nev: Domokos Nikolette - Beatrice
//Csoport: 511/2
//Lab1 5.feladat
//
// Rendezzuk egy kormentes egyszeru iranyitott graf csucsait olyan sorrendbe, hogy minden el balrol jobbra (egy korabbi csucsbol egy kesobbi csucsba) mutasson.

#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

#define MAX_CSUCS 1000001

using namespace std;

string inout = "help.";

void Beolvas(vector <vector <int> >& g, int& n, int& m);

void Rek_Modositott_Melysegi(const vector < vector < int > >& g, int p, stack <int>& sorrend, int* volt);

void Topologiai_Rendezes(const vector < vector < int > >& g,int n, stack <int>& sorrend);

void Kiiras(stack <int> s);

int main()
{
	vector <vector <int> > graf;
	int n, m;

	Beolvas(graf, n, m);

	stack <int> sorrend;

	Topologiai_Rendezes(graf, n, sorrend);
	Kiiras(sorrend);

	graf.clear();

	return 0;
}



void Beolvas(vector <vector <int> >& g, int& n, int& m)		//beolvassuk a graf ellistajat -> felepitjuk a szomszedsagi listat
{
	ifstream in(inout + "in");
	in >> n >> m;

	g.resize(n);

	int u, v;
	for (int i = 0; i < m; ++i)
	{
		in >> u >> v;
		u--;
		v--;

		g[u].push_back(v);

	}

	in.close();
}

void Rek_Modositott_Melysegi(const vector < vector < int > >& g, int p, stack <int>& sorrend, int* volt)		//modositott melysegi bejaras
{
	if (volt[p] != 2)													//ha nem kettovel jelolt a csucs, azaz meg nem jartuk be teljesen a szomszedait
	{
		volt[p] = 1;													//akkor 1-ssel jeloljuk, jelezve, hogy itt vagyunk
		for (int i = 0; i < g[p].size(); ++i)							//bejarjuk az aktualis csucs szomszedait
			if (volt[g[p][i]] == 0)										//ha meg nem latogattuk meg az egyik szomszedjat, akkor arra meghivjuk a modositott melysegi bejarast
			{
				Rek_Modositott_Melysegi(g, g[p][i], sorrend, volt);
			}
		volt[p] = 2;													//a csucs szomszedainak bejarast kovetoen a csucsot 2-re allitjuk, hogy a kovetkezokben erre ne lepjen
		sorrend.push(p);												//betesszuk a sorrendbe
	}
}

void Topologiai_Rendezes(const vector < vector < int > >& g, int n, stack <int>& sorrend)
{
	int* volt = new int[n] {0};								//eleinte minden csucsot 0-val jelolunk, jelezve, hogy meg nem voltak

	for (int i = 0; i < n; ++i)								//bejarjuk a grafot
		Rek_Modositott_Melysegi(g, i, sorrend, volt);
	
	delete[] volt;
}

void Kiiras(stack <int> s)						//fuggveny amely kiiratja a topologiai sorrendet egy allomanyba
{
	ofstream out(inout + "out");

	while (!s.empty())
	{
		out << s.top() + 1 << " ";
		s.pop();
	}

	out.close();
}