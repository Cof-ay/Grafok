// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Lab1 1.feladat
//
//Adott egy iranyitatlan multigraf. Irassuk ki a szomszedsagi matrixat, a szomszedsagi listakat, a csucsok fokszamait, valamint soroljuk fel az izolalt pontokat �s a vegpontokat.s

#include <iostream>
#include <vector>
#include <fstream>

#define MAX_CSUCS 1001
#define MAX_EL 1000001

using namespace std;

string inout = "lab1_1_1.";

void Beolvas(vector <vector <int> >& g, int& n, int& m);

void Lista_Rendez(vector <vector <int> >& graf, int n, int m);

void Rendez(vector <int>& gi, int n, int m);

void Szomszedsagi_Matrix_Epit(const vector <vector <int> >& graf, vector <vector <int> >& matrix, int n, int m);

void Szomszedsagi_Matrix_Kiir(const vector <vector <int> >& matrix, int n, ofstream& out);

void Szomszedok(const vector <vector <int> >& graf,int n, ofstream& out);

void Fokszamok(const vector <vector <int> >& graf, int n, ofstream& out);

void Izolalt_Pontok(const vector <vector <int> >& graf, int n, ofstream& out);

void Vegpontok(const vector <vector <int> >& graf, int n, ofstream& out);

int main()
{
	vector <vector <int> > graf;
	vector <vector <int> > matrix;
	int n, m;

	ofstream out(inout + "out");

	Beolvas(graf, n, m);
	Lista_Rendez(graf, n, m);

	Szomszedsagi_Matrix_Epit(graf,matrix, n, m);
	Szomszedsagi_Matrix_Kiir(matrix, n, out);

	Szomszedok(graf, n, out);
	Fokszamok(graf, n, out);
	Izolalt_Pontok(graf, n, out);
	Vegpontok(graf, n, out);

	graf.clear();
	matrix.clear();
	out.close();

	return 0;
}

void Beolvas(vector <vector <int> >& g, int& n, int& m)		//beolvassuk a graf ellistajat -> felepitjuk a szomszedsagi listat
{
	ifstream in(inout + "in");
	in >> n >> m;

	g.resize(n);								

	int u, v;
	for (int i = 0; i < m; ++i)
	{
		in >> u >> v;
		u--;
		v--;

		g[u].push_back(v);
		g[v].push_back(u);

	}

	in.close();
}

void Lista_Rendez(vector <vector <int> >& graf, int n, int m)	//rendezzuk a listan beluli listak elemeit novekvo sorrendbe
{
	for (int i = 0; i < n; ++i)
	{
		if (graf[i].size() > 1)
			Rendez(graf[i], n, m);
	}
}

void Rendez(vector <int>& gi, int n, int m)					//count sort a listak rendezesere
{
	int* elofordulas = new int[MAX_CSUCS];
	vector <int> seged;
	seged.resize(gi.size());

	for (int i = 0; i < MAX_CSUCS; ++i)
		elofordulas[i] = -1;

	for (int i = 0; i < gi.size(); ++i)
	{
		elofordulas[gi[i]]++;
	}

	for (int i = 1; i < MAX_CSUCS; ++i)
		if (elofordulas[i - 1] != -1)
		{
			elofordulas[i] += elofordulas[i - 1] + 1;
		}

	for (int i = gi.size() - 1; i >= 0; --i)
	{
		seged[elofordulas[gi[i]]] = gi[i];
		elofordulas[gi[i]]--;
	}

	seged.swap(gi);
	
	seged.clear();
	delete[] elofordulas;
}

void Szomszedsagi_Matrix_Epit(const vector <vector <int> >& graf, vector <vector <int> >& matrix, int n, int m)		//a szomszedsagi listabol felepitjuk a matrixot
{
	matrix.resize(n);

	for (int i = 0; i < n; ++i)
	{
		matrix[i].resize(n);

		if (graf[i].size())																						//vizsgaljuk, hogy az aktulais csomopont nem izolalt-e
		{
			for (int j = 0; j < graf[i].size(); ++j)															//bejarjuk alistat
			{
					matrix[i][graf[i][j]]++;																	//feltoltjuk a megfelelo mezoket
			}
		}

		
	}
}

void Szomszedsagi_Matrix_Kiir(const vector <vector <int> >& matrix, int n, ofstream& out)				//fuggveny amely kiiratja szovegallomanyba a szomszedsagi matrixot
{
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; j++)
			out << matrix[i][j] << " ";
		out << endl;
	}
	out << endl;
}

void Szomszedok(const vector <vector <int> >& graf, int n, ofstream& out)		//fuggveny amely kiiratja szovegallomanyba minden csomopontnak a szomszedjat
{
	bool ellenor;																//hurok elek szomszedainak helyes kiiratasanak erdekeben bevezetunk egy orszemet

	for (int i = 0; i < n; ++i)													//bejarjuk a listat
	{	
		ellenor = true;
		out << i + 1 << ": ";													//kiiratjuk az aktualis csomopontot
		for (int j = 0; j < graf[i].size(); ++j)								//bejarjuk az aktualis csomoponthoz tartozo listat
		{
			if (i == graf[i][j])												//vizsgaljuk, hogy hurokelrol van-e szo
			{
				if (ellenor)													//az ellenor orszemmel biztosra megyunk, hogy csakis egyszer irassuk ki a csomopontot mint onmaganak a szomszedjat
				{
					out << graf[i][j] + 1 << " ";
					ellenor = false;
				}
			}
			else
			{
				out << graf[i][j] + 1 << " ";									//kiiratjuk a csomopontot
			}
		}

		out << endl;
	}
	out << endl;
}

void Fokszamok(const vector <vector <int> >& graf, int n, ofstream& out)		//fuggeveny amely kiiratja a csomopontok fokszamait
{
	out << "Fokszamok: ";

	for (int i = 0; i < n; i++)
		out << graf[i].size() << " ";											//mivel fel van epitve a szomszedsagi lista, ezert eleg a csomopontokhoz tartozo listak meretet lekerni hogy megkapjuk a fokszamot
	out << endl;
}

void Izolalt_Pontok(const vector <vector <int> >& graf, int n, ofstream& out)	//fuggveny amely kiiratja az izolalt csomopontokat
{
	out << "Izolalt pontok: ";

	for (int i = 0; i < n; ++i)
		if (graf[i].size() == 0)									//mivel fel van epitve a szomszedsagi lista, ezert eleg lekerni a csomoponthoz tartozo listanak a meretet, ha az 0 akkor izolalt a pont
			out << i + 1 << " ";
	out << endl;
}

void Vegpontok(const vector <vector <int> >& graf, int n, ofstream& out)	//fuggveny amely kiiratja a vegpontokat
{
	out << "Vegpontok: ";

	for (int i = 0; i < n; ++i)
		if (graf[i].size() == 1)							//mivel fel van epitve a szomszedsagi lista, ezert eleg lekerni a csomoponthoz tartozo listanak a meretet, ha az 1, akkor a pont vegpont
			out << i + 1 << " ";
	out << endl;
}