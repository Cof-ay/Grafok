// Nev: Domokos Nikolette - Beatrice
// Csoport: 511/2
// Lab1 3.feladat
//
// Allapitsuk meg egy iranyitatlan multigraf osszefuggo komponenseit a fenti bejarasok valamelyiket hasznalva (2.feladatbol).

#include <iostream>
#include <vector>
#include <fstream>
#include <queue>

#define MAX_CSUCS 1000001

using namespace std;

string inout = "lab1_3_5.";

void Beolvas(vector <vector <int> >& g, int& n, int& m);

void Szelessegi(const vector <vector <int> >& g, int v, vector <int>& sorrendi, bool* volt);

void Osszefuggo_Komponensek(const vector <vector <int> >& g, int n, vector <vector <int> >& sorrend, int& db);

void Kiiras(const vector <vector <int> >& sorrend, int db);

int main()
{
	vector <vector <int> > graf;
	int n, m;

	Beolvas(graf, n, m);

	vector <vector <int> > sorrend;
	int db = 0;

	Osszefuggo_Komponensek(graf, n, sorrend, db);
	Kiiras(sorrend, db);

	sorrend.clear();
	graf.clear();

	return 0;
}

void Beolvas(vector <vector <int> >& g, int& n, int& m)		//beolvassuk a graf ellistajat -> felepitjuk a szomszedsagi listat
{
	ifstream in(inout+"in");
	in >> n >> m;

	g.resize(n);

	int u, v;
	for (int i = 0; i < m; ++i)
	{
		in >> u >> v;
		u--;
		v--;

		g[u].push_back(v);
		g[v].push_back(u);

	}

	in.close();
}

void Szelessegi(const vector <vector <int> >& g, int v, vector <int>& sorrendi, bool* volt)		//a graf szelessegi bejarasat megvalosito fuggveny
{
	queue <int> q;
	volt[v] = true;
	sorrendi.push_back(v);
	q.push(v);
	int u;
	while (!q.empty())
	{
		u = q.front();
		for (int i = 0; i < g[u].size(); ++i)
		{
			if (volt[g[u][i]] == false)
			{
				volt[g[u][i]] = true;
				sorrendi.push_back(g[u][i]);
				q.push(g[u][i]);
			}
		}
		q.pop();
	}
}

void Osszefuggo_Komponensek(const vector <vector <int> >& g, int n, vector <vector <int> >& sorrend, int& db)	//fuggveny amely meghatarozza egy graf osszefuggo komponenseit es azok szamat
{
	sorrend.resize(n);									//lefoglalunk elore n listat a sorrend listaban, mivel maximum n db osszefuggo komponensunk lehet

	bool* volt = new bool[n] {false};					//elofordulasi tomb

	for (int i = 0; i < n; ++i)							//bejarjuk a csucspontokat
	{
		if (volt[i] == false)							//ha az egyik nem volt, akkor azt egy kiindulasicsucsnak vesszuk
		{
			Szelessegi(g, i, sorrend[db], volt);		//bejarjuk az aktualis csucsbol kiindulva a grafot
											
				db++;									//noveljuk a darabszamot
		}
	}

	sorrend.shrink_to_fit();
	delete[] volt;
}

void Kiiras(const vector <vector <int> >& sorrend, int db)			//fuggveny amely kiirja egy allomanyba a sorrend ket dimenzios vectort
{
	ofstream out(inout + "out");
	out << db << endl;

	for (int i = 0; i < sorrend.size(); ++i)
	{
		if (sorrend[i].size())
		{
			for (int j = 0; j < sorrend[i].size(); ++j)
				out << sorrend[i][j] + 1 << " ";
			out << endl;
		}
	}

	out.close();
}